# WordPress MySQL database migration
#
# Generated: Wednesday 19. November 2014 13:13 UTC
# Hostname: localhost
# Database: `denimhouse`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `dh_commentmeta`
#

DROP TABLE IF EXISTS `dh_commentmeta`;


#
# Table structure of table `dh_commentmeta`
#

CREATE TABLE `dh_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_commentmeta`
#

#
# End of data contents of table `dh_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `dh_comments`
#

DROP TABLE IF EXISTS `dh_comments`;


#
# Table structure of table `dh_comments`
#

CREATE TABLE `dh_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_comments`
#
INSERT INTO `dh_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-10-23 10:34:23', '2014-10-23 10:34:23', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `dh_comments`
# --------------------------------------------------------



#
# Delete any existing table `dh_links`
#

DROP TABLE IF EXISTS `dh_links`;


#
# Table structure of table `dh_links`
#

CREATE TABLE `dh_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_links`
#

#
# End of data contents of table `dh_links`
# --------------------------------------------------------



#
# Delete any existing table `dh_options`
#

DROP TABLE IF EXISTS `dh_options`;


#
# Table structure of table `dh_options`
#

CREATE TABLE `dh_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=595 DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_options`
#
INSERT INTO `dh_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/denimhouse', 'yes'),
(2, 'home', 'http://localhost/denimhouse', 'yes'),
(3, 'blogname', 'Denim House', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'admin@denimhouse.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'gzipcompression', '0', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:29:"pie-register/pie-register.php";i:1;s:27:"woocommerce/woocommerce.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '0', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', '', 'no'),
(41, 'template', 'enigma', 'yes'),
(42, 'stylesheet', 'enigma', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '0', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'customer', 'yes'),
(49, 'db_version', '29630', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '0', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'page', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '0', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '0', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:0:{}', 'yes'),
(81, 'widget_rss', 'a:0:{}', 'yes'),
(82, 'uninstall_plugins', 'a:1:{s:39:"si-captcha-for-wordpress/si-captcha.php";s:24:"si_captcha_unset_options";}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '0', 'yes'),
(85, 'page_on_front', '10', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '29630', 'yes'),
(89, 'dh_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:132:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:3:{s:4:"read";b:1;s:10:"edit_posts";b:0;s:12:"delete_posts";b:0;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop Manager";s:12:"capabilities";a:110:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_users";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:15:"unfiltered_html";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;}}}', 'yes'),
(90, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:0:{}s:18:"footer-widget-area";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(96, 'cron', 'a:9:{i:1416404945;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1416424680;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1416436529;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1416436530;a:2:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1416438116;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1416441600;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1416479742;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1416481150;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(107, 'can_compress_scripts', '0', 'yes'),
(114, 'recently_activated', 'a:0:{}', 'yes'),
(128, 'woocommerce_default_country', 'ID:JK', 'yes'),
(129, 'woocommerce_allowed_countries', 'all', 'yes') ;
INSERT INTO `dh_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(130, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(131, 'woocommerce_demo_store', 'no', 'yes'),
(132, 'woocommerce_demo_store_notice', 'This is a demo store for testing purposes — no orders shall be fulfilled.', 'no'),
(133, 'woocommerce_api_enabled', 'yes', 'yes'),
(134, 'woocommerce_currency', 'IDR', 'yes'),
(135, 'woocommerce_currency_pos', 'left_space', 'yes'),
(136, 'woocommerce_price_thousand_sep', '.', 'yes'),
(137, 'woocommerce_price_decimal_sep', ',', 'yes'),
(138, 'woocommerce_price_num_decimals', '2', 'yes'),
(139, 'woocommerce_enable_lightbox', 'yes', 'yes'),
(140, 'woocommerce_enable_chosen', 'yes', 'no'),
(141, 'woocommerce_shop_page_id', '13', 'yes'),
(142, 'woocommerce_shop_page_display', '', 'yes'),
(143, 'woocommerce_category_archive_display', '', 'yes'),
(144, 'woocommerce_default_catalog_orderby', 'menu_order', 'yes'),
(145, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(146, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(147, 'woocommerce_weight_unit', 'kg', 'yes'),
(148, 'woocommerce_dimension_unit', 'cm', 'yes'),
(149, 'woocommerce_enable_review_rating', 'yes', 'no'),
(150, 'woocommerce_review_rating_required', 'yes', 'no'),
(151, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(152, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(153, 'shop_catalog_image_size', 'a:3:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";}', 'yes'),
(154, 'shop_single_image_size', 'a:3:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";s:1:"1";}', 'yes'),
(155, 'shop_thumbnail_image_size', 'a:3:{s:5:"width";s:2:"90";s:6:"height";s:2:"90";s:4:"crop";s:1:"1";}', 'yes'),
(156, 'woocommerce_file_download_method', 'force', 'no'),
(157, 'woocommerce_downloads_require_login', 'no', 'no'),
(158, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(159, 'woocommerce_manage_stock', 'yes', 'yes'),
(160, 'woocommerce_hold_stock_minutes', '60', 'no'),
(161, 'woocommerce_notify_low_stock', 'yes', 'no'),
(162, 'woocommerce_notify_no_stock', 'yes', 'no'),
(163, 'woocommerce_stock_email_recipient', 'admin@denimhouse.com', 'no'),
(164, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(165, 'woocommerce_notify_no_stock_amount', '0', 'no'),
(166, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(167, 'woocommerce_stock_format', '', 'yes'),
(168, 'woocommerce_calc_taxes', 'no', 'yes'),
(169, 'woocommerce_prices_include_tax', 'no', 'yes'),
(170, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(171, 'woocommerce_default_customer_address', 'base', 'yes'),
(172, 'woocommerce_shipping_tax_class', 'title', 'yes'),
(173, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(174, 'woocommerce_tax_classes', 'Reduced Rate\nZero Rate', 'yes'),
(175, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(176, 'woocommerce_price_display_suffix', '', 'yes'),
(177, 'woocommerce_tax_display_cart', 'excl', 'no'),
(178, 'woocommerce_tax_total_display', 'itemized', 'no'),
(179, 'woocommerce_enable_coupons', 'yes', 'no'),
(180, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(181, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(182, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(183, 'woocommerce_cart_page_id', '', 'yes'),
(184, 'woocommerce_checkout_page_id', '', 'yes'),
(185, 'woocommerce_terms_page_id', '', 'no'),
(186, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(187, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(188, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(189, 'woocommerce_calc_shipping', 'yes', 'yes'),
(190, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(191, 'woocommerce_shipping_cost_requires_address', 'no', 'no'),
(192, 'woocommerce_shipping_method_format', '', 'no'),
(193, 'woocommerce_ship_to_billing', 'yes', 'no'),
(194, 'woocommerce_ship_to_billing_address_only', 'no', 'no'),
(195, 'woocommerce_ship_to_countries', '', 'yes'),
(196, 'woocommerce_specific_ship_to_countries', '', 'yes'),
(197, 'woocommerce_myaccount_page_id', '', 'yes'),
(198, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(199, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(200, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(201, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(202, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(203, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'),
(204, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(205, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(206, 'woocommerce_registration_generate_username', 'yes', 'no'),
(207, 'woocommerce_registration_generate_password', 'no', 'no'),
(208, 'woocommerce_email_from_name', 'Denim House', 'no'),
(209, 'woocommerce_email_from_address', 'admin@denimhouse.com', 'no'),
(210, 'woocommerce_email_header_image', '', 'no'),
(211, 'woocommerce_email_footer_text', 'Denim House - Powered by WooCommerce', 'no'),
(212, 'woocommerce_email_base_color', '#557da1', 'no'),
(213, 'woocommerce_email_background_color', '#f5f5f5', 'no'),
(214, 'woocommerce_email_body_background_color', '#fdfdfd', 'no'),
(215, 'woocommerce_email_text_color', '#505050', 'no'),
(217, 'woocommerce_db_version', '2.2.7', 'yes'),
(218, 'woocommerce_version', '2.2.7', 'yes'),
(228, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(230, 'woocommerce_ship_to_destination', 'shipping', 'no'),
(234, 'woocommerce_admin_notices', 'a:2:{i:0;s:14:"template_files";i:1;s:13:"theme_support";}', 'yes'),
(268, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1414061769;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(269, 'current_theme', 'Enigma', 'yes'),
(270, 'theme_mods_enigma', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:13;}}', 'yes'),
(271, 'theme_switched', '', 'yes'),
(288, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(323, 'category_children', 'a:0:{}', 'yes'),
(329, 'enigma_options', 'a:65:{s:17:"upload_image_logo";s:0:"";s:6:"height";s:2:"55";s:5:"width";s:3:"150";s:10:"text_title";s:3:"off";s:20:"upload_image_favicon";s:0:"";s:10:"custom_css";s:0:"";s:13:"slide_image_1";s:65:"http://localhost/denimhouse/wp-content/themes/enigma/images/1.png";s:13:"slide_title_1";s:11:"Slide Title";s:12:"slide_desc_1";s:59:"tudi v priljubljenih programih za namizno založništvo kot";s:16:"slide_btn_text_1";s:9:"Read More";s:16:"slide_btn_link_1";s:1:"#";s:13:"slide_image_2";s:65:"http://localhost/denimhouse/wp-content/themes/enigma/images/2.png";s:13:"slide_title_2";s:12:"Lorem Ipsuma";s:12:"slide_desc_2";s:53:"kombinacijo znakov neznani tiskar združil v vzorčno";s:16:"slide_btn_text_2";s:9:"Read More";s:16:"slide_btn_link_2";s:1:"#";s:13:"slide_image_3";s:65:"http://localhost/denimhouse/wp-content/themes/enigma/images/3.png";s:13:"slide_title_3";s:19:" zgolj naključno e";s:12:"slide_desc_3";s:44:"nenačrtovano ali namenoma, z različnimi š";s:16:"slide_btn_text_3";s:9:"Read More";s:16:"slide_btn_link_3";s:1:"#";s:10:"blog_title";s:11:"Latest Blog";s:8:"fc_title";s:75:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ";s:10:"fc_btn_txt";s:13:"More Features";s:11:"fc_btn_link";s:1:"#";s:30:"header_social_media_in_enabled";s:2:"on";s:34:"footer_section_social_media_enbled";s:2:"on";s:12:"twitter_link";s:20:"https://twitter.com/";s:7:"fb_link";s:20:"https://facebook.com";s:13:"linkedin_link";s:20:"http://linkedin.com/";s:12:"youtube_link";s:20:"https://youtube.com/";s:8:"email_id";s:17:"enigma@mymail.com";s:8:"phone_no";s:10:"0159753586";s:21:"footer_customizations";s:25:" &#169; 2014 Enigma Theme";s:17:"developed_by_text";s:18:"Theme Developed By";s:26:"developed_by_weblizar_text";s:15:"Weblizar Themes";s:17:"developed_by_link";s:20:"http://weblizar.com/";s:20:"home_service_heading";s:12:"Our Services";s:15:"service_1_title";s:4:"Idea";s:15:"service_1_icons";s:12:"fa fa-google";s:14:"service_1_text";s:109:"There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in.";s:14:"service_1_link";s:1:"#";s:15:"service_2_title";s:7:"Records";s:15:"service_2_icons";s:14:"fa fa-database";s:14:"service_2_text";s:109:"There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in.";s:14:"service_2_link";s:1:"#";s:15:"service_3_title";s:9:"WordPress";s:15:"service_3_icons";s:15:"fa fa-wordpress";s:14:"service_3_text";s:109:"There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in.";s:14:"service_3_link";s:1:"#";s:14:"portfolio_home";s:3:"off";s:12:"port_heading";s:12:"Recent Works";s:10:"port_1_img";s:74:"http://localhost/denimhouse/wp-content/themes/enigma/images/portfolio1.png";s:12:"port_1_title";s:11:"modsætning";s:11:"port_1_link";s:1:"#";s:10:"port_2_img";s:74:"http://localhost/denimhouse/wp-content/themes/enigma/images/portfolio2.png";s:12:"port_2_title";s:7:"udgaver";s:11:"port_2_link";s:1:"#";s:10:"port_3_img";s:74:"http://localhost/denimhouse/wp-content/themes/enigma/images/portfolio3.png";s:12:"port_3_title";s:7:"udgaver";s:11:"port_3_link";s:1:"#";s:10:"port_4_img";s:74:"http://localhost/denimhouse/wp-content/themes/enigma/images/portfolio4.png";s:12:"port_4_title";s:7:"udgaver";s:11:"port_4_link";s:1:"#";s:41:"weblizar_settings_save_portfolio-settings";s:1:"1";}', 'yes'),
(330, 'woocommerce_permalinks', 'a:4:{s:13:"category_base";s:0:"";s:8:"tag_base";s:0:"";s:14:"attribute_base";s:0:"";s:12:"product_base";s:19:"/shop/%product_cat%";}', 'yes'),
(336, 'woocommerce_frontend_css_colors', 'a:5:{s:7:"primary";s:7:"#ad74a2";s:9:"secondary";s:7:"#f7f6f7";s:9:"highlight";s:7:"#85ad74";s:10:"content_bg";s:7:"#ffffff";s:7:"subtext";s:7:"#777777";}', 'yes') ;
INSERT INTO `dh_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(341, 'rewrite_rules', 'a:166:{s:22:"^wc-api/v([1-2]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-2]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:11:"products/?$";s:27:"index.php?post_type=product";s:41:"products/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:36:"products/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:28:"products/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:55:"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:43:"product-category/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"product-category/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:52:"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:47:"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:40:"product-tag/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:22:"product-tag/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:36:"shop/.+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"shop/.+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"shop/.+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"shop/.+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"shop/.+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"shop/(.+?)/([^/]+)/trackback/?$";s:58:"index.php?product_cat=$matches[1]&product=$matches[2]&tb=1";s:51:"shop/(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:70:"index.php?product_cat=$matches[1]&product=$matches[2]&feed=$matches[3]";s:46:"shop/(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:70:"index.php?product_cat=$matches[1]&product=$matches[2]&feed=$matches[3]";s:39:"shop/(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:71:"index.php?product_cat=$matches[1]&product=$matches[2]&paged=$matches[3]";s:46:"shop/(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:71:"index.php?product_cat=$matches[1]&product=$matches[2]&cpage=$matches[3]";s:36:"shop/(.+?)/([^/]+)/wc-api(/(.*))?/?$";s:72:"index.php?product_cat=$matches[1]&product=$matches[2]&wc-api=$matches[4]";s:40:"shop/.+?/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:51:"shop/.+?/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:31:"shop/(.+?)/([^/]+)(/[0-9]+)?/?$";s:70:"index.php?product_cat=$matches[1]&product=$matches[2]&page=$matches[3]";s:25:"shop/.+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"shop/.+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"shop/.+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"shop/.+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"shop/.+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"product_variation/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"product_variation/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"product_variation/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"product_variation/([^/]+)/trackback/?$";s:44:"index.php?product_variation=$matches[1]&tb=1";s:46:"product_variation/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&paged=$matches[2]";s:53:"product_variation/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&cpage=$matches[2]";s:43:"product_variation/([^/]+)/wc-api(/(.*))?/?$";s:58:"index.php?product_variation=$matches[1]&wc-api=$matches[3]";s:49:"product_variation/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"product_variation/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:38:"product_variation/([^/]+)(/[0-9]+)?/?$";s:56:"index.php?product_variation=$matches[1]&page=$matches[2]";s:34:"product_variation/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"product_variation/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"product_variation/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"shop_order_refund/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"shop_order_refund/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"shop_order_refund/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"shop_order_refund/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"shop_order_refund/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"shop_order_refund/([^/]+)/trackback/?$";s:44:"index.php?shop_order_refund=$matches[1]&tb=1";s:46:"shop_order_refund/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?shop_order_refund=$matches[1]&paged=$matches[2]";s:53:"shop_order_refund/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?shop_order_refund=$matches[1]&cpage=$matches[2]";s:43:"shop_order_refund/([^/]+)/wc-api(/(.*))?/?$";s:58:"index.php?shop_order_refund=$matches[1]&wc-api=$matches[3]";s:49:"shop_order_refund/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"shop_order_refund/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:38:"shop_order_refund/([^/]+)(/[0-9]+)?/?$";s:56:"index.php?shop_order_refund=$matches[1]&page=$matches[2]";s:34:"shop_order_refund/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"shop_order_refund/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"shop_order_refund/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"shop_order_refund/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"shop_order_refund/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=10&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:20:"order-pay(/(.*))?/?$";s:32:"index.php?&order-pay=$matches[2]";s:25:"order-received(/(.*))?/?$";s:37:"index.php?&order-received=$matches[2]";s:21:"view-order(/(.*))?/?$";s:33:"index.php?&view-order=$matches[2]";s:23:"edit-account(/(.*))?/?$";s:35:"index.php?&edit-account=$matches[2]";s:23:"edit-address(/(.*))?/?$";s:35:"index.php?&edit-address=$matches[2]";s:24:"lost-password(/(.*))?/?$";s:36:"index.php?&lost-password=$matches[2]";s:26:"customer-logout(/(.*))?/?$";s:38:"index.php?&customer-logout=$matches[2]";s:29:"add-payment-method(/(.*))?/?$";s:41:"index.php?&add-payment-method=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:25:"([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?name=$matches[1]&wc-api=$matches[3]";s:31:"[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes'),
(357, 'product_cat_children', 'a:0:{}', 'yes'),
(358, 'product_shipping_class_children', 'a:0:{}', 'yes'),
(385, 'WPLANG', '', 'yes'),
(471, 'wppb_general_settings', 'a:5:{s:17:"extraFieldsLayout";s:7:"default";s:17:"emailConfirmation";s:2:"no";s:21:"activationLandingPage";s:0:"";s:13:"adminApproval";s:2:"no";s:9:"loginWith";s:8:"username";}', 'yes'),
(472, 'wppb_manage_fields', 'a:13:{i:0;a:21:{s:5:"field";s:24:"Default - Name (Heading)";s:11:"field-title";s:4:"Name";s:9:"meta-name";s:0:"";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:1:"1";s:11:"description";s:0:"";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:2:"No";}i:1;a:21:{s:5:"field";s:18:"Default - Username";s:11:"field-title";s:8:"Username";s:9:"meta-name";s:0:"";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:1:"2";s:11:"description";s:28:"Usernames cannot be changed.";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:3:"Yes";}i:2;a:21:{s:5:"field";s:20:"Default - First Name";s:11:"field-title";s:10:"First Name";s:9:"meta-name";s:10:"first_name";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:1:"3";s:11:"description";s:0:"";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:2:"No";}i:3;a:21:{s:5:"field";s:19:"Default - Last Name";s:11:"field-title";s:9:"Last Name";s:9:"meta-name";s:9:"last_name";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:1:"4";s:11:"description";s:0:"";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:2:"No";}i:4;a:21:{s:5:"field";s:18:"Default - Nickname";s:11:"field-title";s:8:"Nickname";s:9:"meta-name";s:8:"nickname";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:1:"5";s:11:"description";s:0:"";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:3:"Yes";}i:5;a:21:{s:5:"field";s:34:"Default - Display name publicly as";s:11:"field-title";s:24:"Display name publicly as";s:9:"meta-name";s:0:"";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:1:"6";s:11:"description";s:0:"";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:2:"No";}i:6;a:21:{s:5:"field";s:32:"Default - Contact Info (Heading)";s:11:"field-title";s:12:"Contact Info";s:9:"meta-name";s:0:"";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:1:"7";s:11:"description";s:0:"";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:2:"No";}i:7;a:21:{s:5:"field";s:16:"Default - E-mail";s:11:"field-title";s:6:"E-mail";s:9:"meta-name";s:0:"";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:1:"8";s:11:"description";s:0:"";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:3:"Yes";}i:8;a:21:{s:5:"field";s:17:"Default - Website";s:11:"field-title";s:7:"Website";s:9:"meta-name";s:0:"";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:1:"9";s:11:"description";s:0:"";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:2:"No";}i:9;a:21:{s:5:"field";s:34:"Default - About Yourself (Heading)";s:11:"field-title";s:14:"About Yourself";s:9:"meta-name";s:0:"";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:2:"13";s:11:"description";s:0:"";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:2:"No";}i:10;a:20:{s:5:"field";s:27:"Default - Biographical Info";s:11:"field-title";s:17:"Biographical Info";s:9:"meta-name";s:11:"description";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:2:"14";s:11:"description";s:93:"Share a little biographical information to fill out your profile. This may be shown publicly.";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:8:"required";s:2:"No";}i:11;a:21:{s:5:"field";s:18:"Default - Password";s:11:"field-title";s:8:"Password";s:9:"meta-name";s:0:"";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:2:"15";s:11:"description";s:19:"Type your password.";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:3:"Yes";}i:12;a:21:{s:5:"field";s:25:"Default - Repeat Password";s:11:"field-title";s:15:"Repeat Password";s:9:"meta-name";s:0:"";s:18:"overwrite-existing";s:2:"No";s:2:"id";s:2:"16";s:11:"description";s:26:"Type your password again. ";s:9:"row-count";s:1:"5";s:24:"allowed-image-extensions";s:2:".*";s:25:"allowed-upload-extensions";s:2:".*";s:11:"avatar-size";s:3:"100";s:11:"date-format";s:8:"mm/dd/yy";s:18:"terms-of-agreement";s:0:"";s:7:"options";s:0:"";s:6:"labels";s:0:"";s:10:"public-key";s:0:"";s:11:"private-key";s:0:"";s:13:"default-value";s:0:"";s:14:"default-option";s:0:"";s:15:"default-options";s:0:"";s:15:"default-content";s:0:"";s:8:"required";s:3:"Yes";}}', 'yes'),
(473, 'wppb_version', '2.0.4', 'yes'),
(478, 'si_captcha', 'a:33:{s:18:"si_captcha_donated";s:5:"false";s:15:"si_captcha_perm";s:4:"true";s:21:"si_captcha_perm_level";s:4:"read";s:18:"si_captcha_comment";s:4:"true";s:33:"si_captcha_comment_label_position";s:20:"input-label-required";s:16:"si_captcha_login";s:5:"false";s:19:"si_captcha_register";s:4:"true";s:18:"si_captcha_lostpwd";s:4:"true";s:20:"si_captcha_rearrange";s:4:"true";s:25:"si_captcha_enable_session";s:5:"false";s:24:"si_captcha_captcha_small";s:5:"false";s:26:"si_captcha_honeypot_enable";s:5:"false";s:24:"si_captcha_aria_required";s:5:"false";s:25:"si_captcha_external_style";s:5:"false";s:28:"si_captcha_captcha_div_style";s:14:"display:block;";s:31:"si_captcha_captcha_div_style_sm";s:43:"width:175px; height:45px; padding-top:10px;";s:30:"si_captcha_captcha_div_style_m";s:43:"width:250px; height:60px; padding-top:10px;";s:30:"si_captcha_captcha_image_style";s:59:"border-style:none; margin:0; padding-right:5px; float:left;";s:30:"si_captcha_refresh_image_style";s:51:"border-style:none; margin:0; vertical-align:bottom;";s:34:"si_captcha_captcha_input_div_style";s:52:"display:block; padding-top:15px; padding-bottom:5px;";s:30:"si_captcha_comment_label_style";s:9:"margin:0;";s:30:"si_captcha_comment_field_style";s:11:"width:65px;";s:24:"si_captcha_label_captcha";s:0:"";s:24:"si_captcha_error_spambot";s:0:"";s:26:"si_captcha_error_incorrect";s:0:"";s:22:"si_captcha_error_empty";s:0:"";s:22:"si_captcha_error_token";s:0:"";s:27:"si_captcha_error_unreadable";s:0:"";s:23:"si_captcha_error_cookie";s:0:"";s:22:"si_captcha_error_error";s:0:"";s:29:"si_captcha_required_indicator";s:2:" *";s:26:"si_captcha_tooltip_captcha";s:0:"";s:26:"si_captcha_tooltip_refresh";s:0:"";}', 'yes'),
(481, 'piereg_plugin_db_version', '2.0.13', 'yes'),
(482, 'Profile_page_id', '28', 'yes'),
(483, 'pie_pages', 'a:4:{i:0;i:25;i:1;i:26;i:2;i:27;i:3;i:28;}', 'yes'),
(484, 'pie_countries', 'a:204:{i:0;s:11:"Afghanistan";i:1;s:7:"Albania";i:2;s:7:"Algeria";i:3;s:14:"American Samoa";i:4;s:7:"Andorra";i:5;s:6:"Angola";i:6;s:19:"Antigua and Barbuda";i:7;s:9:"Argentina";i:8;s:7:"Armenia";i:9;s:9:"Australia";i:10;s:7:"Austria";i:11;s:10:"Azerbaijan";i:12;s:7:"Bahamas";i:13;s:7:"Bahrain";i:14;s:10:"Bangladesh";i:15;s:8:"Barbados";i:16;s:7:"Belarus";i:17;s:7:"Belgium";i:18;s:6:"Belize";i:19;s:5:"Benin";i:20;s:7:"Bermuda";i:21;s:6:"Bhutan";i:22;s:7:"Bolivia";i:23;s:22:"Bosnia and Herzegovina";i:24;s:8:"Botswana";i:25;s:6:"Brazil";i:26;s:6:"Brunei";i:27;s:8:"Bulgaria";i:28;s:12:"Burkina Faso";i:29;s:7:"Burundi";i:30;s:8:"Cambodia";i:31;s:8:"Cameroon";i:32;s:6:"Canada";i:33;s:10:"Cape Verde";i:34;s:24:"Central African Republic";i:35;s:4:"Chad";i:36;s:5:"Chile";i:37;s:5:"China";i:38;s:8:"Colombia";i:39;s:7:"Comoros";i:40;s:5:"Congo";i:41;s:10:"Costa Rica";i:42;s:14:"Côte d\'Ivoire";i:43;s:7:"Croatia";i:44;s:4:"Cuba";i:45;s:6:"Cyprus";i:46;s:14:"Czech Republic";i:47;s:7:"Denmark";i:48;s:8:"Djibouti";i:49;s:8:"Dominica";i:50;s:18:"Dominican Republic";i:51;s:10:"East Timor";i:52;s:7:"Ecuador";i:53;s:5:"Egypt";i:54;s:11:"El Salvador";i:55;s:17:"Equatorial Guinea";i:56;s:7:"Eritrea";i:57;s:7:"Estonia";i:58;s:8:"Ethiopia";i:59;s:4:"Fiji";i:60;s:7:"Finland";i:61;s:6:"France";i:62;s:5:"Gabon";i:63;s:6:"Gambia";i:64;s:7:"Georgia";i:65;s:7:"Germany";i:66;s:5:"Ghana";i:67;s:6:"Greece";i:68;s:9:"Greenland";i:69;s:7:"Grenada";i:70;s:4:"Guam";i:71;s:9:"Guatemala";i:72;s:6:"Guinea";i:73;s:13:"Guinea-Bissau";i:74;s:6:"Guyana";i:75;s:5:"Haiti";i:76;s:8:"Honduras";i:77;s:9:"Hong Kong";i:78;s:7:"Hungary";i:79;s:7:"Iceland";i:80;s:5:"India";i:81;s:9:"Indonesia";i:82;s:4:"Iran";i:83;s:4:"Iraq";i:84;s:7:"Ireland";i:85;s:6:"Israel";i:86;s:5:"Italy";i:87;s:7:"Jamaica";i:88;s:5:"Japan";i:89;s:6:"Jordan";i:90;s:10:"Kazakhstan";i:91;s:5:"Kenya";i:92;s:8:"Kiribati";i:93;s:11:"North Korea";i:94;s:11:"South Korea";i:95;s:6:"Kuwait";i:96;s:10:"Kyrgyzstan";i:97;s:4:"Laos";i:98;s:6:"Latvia";i:99;s:7:"Lebanon";i:100;s:7:"Lesotho";i:101;s:7:"Liberia";i:102;s:5:"Libya";i:103;s:13:"Liechtenstein";i:104;s:9:"Lithuania";i:105;s:10:"Luxembourg";i:106;s:9:"Macedonia";i:107;s:10:"Madagascar";i:108;s:6:"Malawi";i:109;s:8:"Malaysia";i:110;s:8:"Maldives";i:111;s:4:"Mali";i:112;s:5:"Malta";i:113;s:16:"Marshall Islands";i:114;s:10:"Mauritania";i:115;s:9:"Mauritius";i:116;s:6:"Mexico";i:117;s:10:"Micronesia";i:118;s:7:"Moldova";i:119;s:6:"Monaco";i:120;s:8:"Mongolia";i:121;s:10:"Montenegro";i:122;s:7:"Morocco";i:123;s:10:"Mozambique";i:124;s:7:"Myanmar";i:125;s:7:"Namibia";i:126;s:5:"Nauru";i:127;s:5:"Nepal";i:128;s:11:"Netherlands";i:129;s:11:"New Zealand";i:130;s:9:"Nicaragua";i:131;s:5:"Niger";i:132;s:7:"Nigeria";i:133;s:6:"Norway";i:134;s:24:"Northern Mariana Islands";i:135;s:4:"Oman";i:136;s:8:"Pakistan";i:137;s:5:"Palau";i:138;s:9:"Palestine";i:139;s:6:"Panama";i:140;s:16:"Papua New Guinea";i:141;s:8:"Paraguay";i:142;s:4:"Peru";i:143;s:11:"Philippines";i:144;s:6:"Poland";i:145;s:8:"Portugal";i:146;s:11:"Puerto Rico";i:147;s:5:"Qatar";i:148;s:7:"Romania";i:149;s:6:"Russia";i:150;s:6:"Rwanda";i:151;s:21:"Saint Kitts and Nevis";i:152;s:11:"Saint Lucia";i:153;s:32:"Saint Vincent and the Grenadines";i:154;s:5:"Samoa";i:155;s:10:"San Marino";i:156;s:21:"Sao Tome and Principe";i:157;s:12:"Saudi Arabia";i:158;s:7:"Senegal";i:159;s:21:"Serbia and Montenegro";i:160;s:10:"Seychelles";i:161;s:12:"Sierra Leone";i:162;s:9:"Singapore";i:163;s:8:"Slovakia";i:164;s:8:"Slovenia";i:165;s:15:"Solomon Islands";i:166;s:7:"Somalia";i:167;s:12:"South Africa";i:168;s:5:"Spain";i:169;s:9:"Sri Lanka";i:170;s:5:"Sudan";i:171;s:12:"Sudan, South";i:172;s:8:"Suriname";i:173;s:9:"Swaziland";i:174;s:6:"Sweden";i:175;s:11:"Switzerland";i:176;s:5:"Syria";i:177;s:6:"Taiwan";i:178;s:10:"Tajikistan";i:179;s:8:"Tanzania";i:180;s:8:"Thailand";i:181;s:4:"Togo";i:182;s:5:"Tonga";i:183;s:19:"Trinidad and Tobago";i:184;s:7:"Tunisia";i:185;s:6:"Turkey";i:186;s:12:"Turkmenistan";i:187;s:6:"Tuvalu";i:188;s:6:"Uganda";i:189;s:7:"Ukraine";i:190;s:20:"United Arab Emirates";i:191;s:14:"United Kingdom";i:192;s:13:"United States";i:193;s:7:"Uruguay";i:194;s:10:"Uzbekistan";i:195;s:7:"Vanuatu";i:196;s:12:"Vatican City";i:197;s:9:"Venezuela";i:198;s:7:"Vietnam";i:199;s:23:"Virgin Islands, British";i:200;s:20:"Virgin Islands, U.S.";i:201;s:5:"Yemen";i:202;s:6:"Zambia";i:203;s:8:"Zimbabwe";}', 'yes'),
(485, 'pie_us_states', 'a:54:{i:0;s:7:"Alabama";i:1;s:6:"Alaska";i:2;s:7:"Arizona";i:3;s:8:"Arkansas";i:4;s:10:"California";i:5;s:8:"Colorado";i:6;s:11:"Connecticut";i:7;s:8:"Delaware";i:8;s:20:"District of Columbia";i:9;s:7:"Florida";i:10;s:7:"Georgia";i:11;s:6:"Hawaii";i:12;s:5:"Idaho";i:13;s:8:"Illinois";i:14;s:7:"Indiana";i:15;s:4:"Iowa";i:16;s:6:"Kansas";i:17;s:8:"Kentucky";i:18;s:9:"Louisiana";i:19;s:5:"Maine";i:20;s:8:"Maryland";i:21;s:13:"Massachusetts";i:22;s:8:"Michigan";i:23;s:9:"Minnesota";i:24;s:11:"Mississippi";i:25;s:8:"Missouri";i:26;s:7:"Montana";i:27;s:8:"Nebraska";i:28;s:6:"Nevada";i:29;s:13:"New Hampshire";i:30;s:10:"New Jersey";i:31;s:10:"New Mexico";i:32;s:8:"New York";i:33;s:14:"North Carolina";i:34;s:12:"North Dakota";i:35;s:4:"Ohio";i:36;s:8:"Oklahoma";i:37;s:6:"Oregon";i:38;s:12:"Pennsylvania";i:39;s:12:"Rhode Island";i:40;s:14:"South Carolina";i:41;s:12:"South Dakota";i:42;s:9:"Tennessee";i:43;s:5:"Texas";i:44;s:4:"Utah";i:45;s:7:"Vermont";i:46;s:8:"Virginia";i:47;s:10:"Washington";i:48;s:13:"West Virginia";i:49;s:9:"Wisconsin";i:50;s:7:"Wyoming";i:51;s:21:"Armed Forces Americas";i:52;s:19:"Armed Forces Europe";i:53;s:20:"Armed Forces Pacific";}', 'yes'),
(486, 'pie_can_states', 'a:13:{i:0;s:7:"Alberta";i:1;s:16:"British Columbia";i:2;s:8:"Manitoba";i:3;s:13:"New Brunswick";i:4;s:25:"Newfoundland and Labrador";i:5;s:21:"Northwest Territories";i:6;s:11:"Nova Scotia";i:7;s:7:"Nunavut";i:8;s:7:"Ontario";i:9;s:20:"Prince Edward Island";i:10;s:6:"Quebec";i:11;s:12:"Saskatchewan";i:12;s:5:"Yukon";}', 'yes'),
(487, 'pie_user_email_types', 'a:11:{s:16:"default_template";s:34:"Default User Registration Template";s:18:"admin_verification";s:18:"Admin Verification";s:18:"email_verification";s:19:"E-Mail Verification";s:14:"email_thankyou";s:17:"Thank You Message";s:15:"pending_payment";s:15:"Pending Payment";s:15:"payment_success";s:15:"Payment Success";s:13:"payment_faild";s:13:"Payment Faild";s:24:"pending_payment_reminder";s:24:"Pending Payment Reminder";s:27:"email_verification_reminder";s:28:"E-Mail Verification Reminder";s:28:"forgot_password_notification";s:28:"Forgot Password Notification";s:23:"email_edit_verification";s:23:"Email Edit Verification";}', 'yes'),
(488, 'pie_register_2', 'a:137:{s:14:"paypal_butt_id";s:0:"";s:10:"paypal_pdt";s:0:"";s:14:"paypal_sandbox";s:0:"";s:26:"enable_admin_notifications";i:1;s:13:"enable_paypal";i:0;s:18:"admin_sendto_email";s:20:"admin@denimhouse.com";s:15:"admin_from_name";s:13:"Administrator";s:16:"admin_from_email";s:20:"admin@denimhouse.com";s:14:"admin_to_email";s:20:"admin@denimhouse.com";s:15:"admin_bcc_email";s:20:"admin@denimhouse.com";s:19:"admin_subject_email";s:21:"New User Registration";s:27:"admin_message_email_formate";i:1;s:19:"admin_message_email";s:134:"<p>Hello Admin,</p><p>A new user has been registered on your Website,. Details are given below:</p><p>Thanks</p><p>Team %blogname%</p>";s:13:"display_hints";i:0;s:13:"redirect_user";i:1;s:16:"subscriber_login";i:0;s:21:"login_form_in_website";i:1;s:23:"registration_in_website";i:1;s:16:"block_WP_profile";i:0;s:21:"allow_pr_edit_wplogin";i:0;s:14:"modify_avatars";i:0;s:14:"show_admin_bar";i:0;s:14:"block_wp_login";i:0;s:15:"alternate_login";i:20;s:18:"alternate_register";i:22;s:20:"alternate_forgotpass";i:27;s:21:"alternate_profilepage";i:28;s:19:"piereg_startingDate";s:4:"1901";s:17:"piereg_endingDate";s:4:"2014";s:11:"after_login";i:-1;s:16:"alternate_logout";i:-1;s:20:"alternate_logout_url";s:0:"";s:9:"outputcss";i:0;s:15:"outputjquery_ui";i:1;s:10:"outputhtml";i:1;s:11:"no_conflict";i:0;s:12:"verification";i:0;s:12:"grace_period";i:0;s:13:"captcha_publc";s:40:"6LfR4_wSAAAAAKc7YMBdYnVdLEo7yKg7UGlTbLiH";s:15:"captcha_private";s:40:"6LfR4_wSAAAAACVLRyFWg6YuWc7ZgIWyXQD3OfxX";s:16:"paypal_button_id";s:0:"";s:16:"paypal_pdt_token";s:0:"";s:10:"custom_css";s:0:"";s:13:"tracking_code";s:0:"";s:23:"enable_invitation_codes";i:0;s:16:"invitation_codes";s:0:"";s:24:"pie_regis_set_user_role_";s:8:"customer";s:15:"custom_logo_url";s:0:"";s:19:"custom_logo_tooltip";s:0:"";s:16:"custom_logo_link";s:0:"";s:16:"show_custom_logo";i:0;s:20:"login_username_label";s:8:"Username";s:26:"login_username_placeholder";s:0:"";s:20:"login_password_label";s:8:"Password";s:26:"login_password_placeholder";s:0:"";s:22:"capthca_in_login_label";s:0:"";s:16:"capthca_in_login";i:0;s:26:"forgot_pass_username_label";s:19:"Username or E-mail:";s:32:"forgot_pass_username_placeholder";s:0:"";s:28:"capthca_in_forgot_pass_label";s:0:"";s:22:"capthca_in_forgot_pass";i:1;s:29:"pass_strength_indicator_label";s:18:"Strength Indicator";s:20:"pass_very_weak_label";s:9:"Very weak";s:15:"pass_weak_label";s:4:"Weak";s:17:"pass_medium_label";s:6:"Medium";s:17:"pass_strong_label";s:6:"Strong";s:19:"pass_mismatch_label";s:8:"Mismatch";s:18:"remove_PR_settings";i:0;s:25:"enable_user_notifications";i:0;s:31:"user_from_name_default_template";s:5:"Admin";s:32:"user_from_email_default_template";s:20:"admin@denimhouse.com";s:30:"user_to_email_default_template";s:20:"admin@denimhouse.com";s:35:"user_subject_email_default_template";s:34:"Default User Registration Template";s:35:"user_formate_email_default_template";i:1;s:33:"user_from_name_admin_verification";s:5:"Admin";s:34:"user_from_email_admin_verification";s:20:"admin@denimhouse.com";s:32:"user_to_email_admin_verification";s:20:"admin@denimhouse.com";s:37:"user_subject_email_admin_verification";s:18:"Admin Verification";s:37:"user_formate_email_admin_verification";i:1;s:33:"user_from_name_email_verification";s:5:"Admin";s:34:"user_from_email_email_verification";s:20:"admin@denimhouse.com";s:32:"user_to_email_email_verification";s:20:"admin@denimhouse.com";s:37:"user_subject_email_email_verification";s:19:"E-Mail Verification";s:37:"user_formate_email_email_verification";i:1;s:29:"user_from_name_email_thankyou";s:5:"Admin";s:30:"user_from_email_email_thankyou";s:20:"admin@denimhouse.com";s:28:"user_to_email_email_thankyou";s:20:"admin@denimhouse.com";s:33:"user_subject_email_email_thankyou";s:17:"Thank You Message";s:33:"user_formate_email_email_thankyou";i:1;s:30:"user_from_name_pending_payment";s:5:"Admin";s:31:"user_from_email_pending_payment";s:20:"admin@denimhouse.com";s:29:"user_to_email_pending_payment";s:20:"admin@denimhouse.com";s:34:"user_subject_email_pending_payment";s:15:"Pending Payment";s:34:"user_formate_email_pending_payment";i:1;s:30:"user_from_name_payment_success";s:5:"Admin";s:31:"user_from_email_payment_success";s:20:"admin@denimhouse.com";s:29:"user_to_email_payment_success";s:20:"admin@denimhouse.com";s:34:"user_subject_email_payment_success";s:15:"Payment Success";s:34:"user_formate_email_payment_success";i:1;s:28:"user_from_name_payment_faild";s:5:"Admin";s:29:"user_from_email_payment_faild";s:20:"admin@denimhouse.com";s:27:"user_to_email_payment_faild";s:20:"admin@denimhouse.com";s:32:"user_subject_email_payment_faild";s:13:"Payment Faild";s:32:"user_formate_email_payment_faild";i:1;s:39:"user_from_name_pending_payment_reminder";s:5:"Admin";s:40:"user_from_email_pending_payment_reminder";s:20:"admin@denimhouse.com";s:38:"user_to_email_pending_payment_reminder";s:20:"admin@denimhouse.com";s:43:"user_subject_email_pending_payment_reminder";s:24:"Pending Payment Reminder";s:43:"user_formate_email_pending_payment_reminder";i:1;s:42:"user_from_name_email_verification_reminder";s:5:"Admin";s:43:"user_from_email_email_verification_reminder";s:20:"admin@denimhouse.com";s:41:"user_to_email_email_verification_reminder";s:20:"admin@denimhouse.com";s:46:"user_subject_email_email_verification_reminder";s:28:"E-Mail Verification Reminder";s:46:"user_formate_email_email_verification_reminder";i:1;s:43:"user_from_name_forgot_password_notification";s:5:"Admin";s:44:"user_from_email_forgot_password_notification";s:20:"admin@denimhouse.com";s:42:"user_to_email_forgot_password_notification";s:20:"admin@denimhouse.com";s:47:"user_subject_email_forgot_password_notification";s:28:"Forgot Password Notification";s:47:"user_formate_email_forgot_password_notification";i:1;s:38:"user_from_name_email_edit_verification";s:5:"Admin";s:39:"user_from_email_email_edit_verification";s:20:"admin@denimhouse.com";s:37:"user_to_email_email_edit_verification";s:20:"admin@denimhouse.com";s:42:"user_subject_email_email_edit_verification";s:23:"Email Edit Verification";s:42:"user_formate_email_email_edit_verification";i:1;s:37:"user_message_email_admin_verification";s:273:"<p>Dear %user_login%,</p><p>Thanks for showing your interest in becoming a registered member of our Wesbite. This is to inform you that your account is under admin moderation and once approved, you will be notified shortly.<br /><br />Best Wishes,</p><p>Team %blogname%</p>";s:37:"user_message_email_email_verification";s:292:"<p>Dear %user_login%,</p><p>You have successfully created an account to our Website. You can access your account by completing the registration and verification process, kindly use the link below to verify your email address.</p><p>%activationurl%</p><p>Best Wishes,</p><p>Team %blogname%</p>";s:33:"user_message_email_email_thankyou";s:225:"<p>Dear %user_login%,</p><p>Thank you for signing-up to our site. We appreciate that you have successfully created an account. If you require any assistance, feel free to contact.</p><p>Kind Regards,</p><p>Team %blogname%</p>";s:34:"user_message_email_payment_success";s:207:"<p>Dear %user_login%,</p><p>Congratulations, you have completed the payment procedure successfully. Now you can avail our features anytime you want.</p><p>Best Regards,</p><p>Team %blogname%</p><p>&nbsp;</p>";s:32:"user_message_email_payment_faild";s:226:"<p>Dear %user_login%,</p><p>Unfortunately the payment attempt from your side has been failed. We request you to kindly Log-In to your account again to complete the payment process.</p><p>Kind Regards,</p><p>Team %blogname%</p>";s:34:"user_message_email_pending_payment";s:244:"<p>Dear %user_login%,</p><p>This Email is sent to you to remind that your payment is still in pending. To avoid any further delay to grab our amazing features, kindly complete the payment procedure.</p><p>Best Regards,</p><p>Team %blogname%</p>";s:35:"user_message_email_default_template";s:233:"<p>Dear %user_login%,</p><p>Thanks for your registration to our Website. Now you can enjoy unlimited benefits of our services and products by just signing in to your personalized account.</p><p>Best Regards,</p><p>Team %blogname%</p>";s:43:"user_message_email_pending_payment_reminder";s:361:"<p>Dear %user_login%,</p><p>We have noticed that you have created an account to the site few days ago, but you did not pay for your account yet. For this we would like to remind you that your payment is still in pending. Kindly complete the payment procedure to avoid any further delays.</p><p>%pending_payment_url%</p><p>Best Regards,</p><p>Team %blogname%</p>";s:46:"user_message_email_email_verification_reminder";s:336:"<p>Dear %user_login%,</p><p>We have noticed that you have created an account to the site few days ago, but you did not verify your email address yet. Kindly follow the link (&nbsp;%activationurl% ) below to complete the verification procedure to become the registered member of our Website.</p><p>Best Regards,</p><p>Team %blogname%</p>";s:47:"user_message_email_forgot_password_notification";s:297:"<p>Dear %user_login%,</p><p>You have just requested for a new password for your account. Please follow the link (&nbsp;%reset_password_url% ) below to reset your password.</p><p>If you have not requested for a new password, kindly ignore this Email.</p><p>Best Regards,</p><p>Team %user_login%</p>";s:42:"user_message_email_email_edit_verification";s:214:"<p>Hello %user_login%,</p><p>You have requested to change of your email address from %user_email% to %user_new_email%. Please click here (%reset_email_url%) to complete the action.</p><p>Thanks</p><p>%blogname%</p>";s:27:"piereg_recapthca_skin_login";s:3:"red";s:33:"piereg_recapthca_skin_forgot_pass";s:3:"red";}', 'yes'),
(489, 'pie_fields', 's:1617:"a:6:{s:4:"form";a:6:{s:4:"type";s:4:"form";s:4:"meta";s:1:"0";s:5:"label";s:17:"Registration Form";s:4:"desc";s:39:"Please fill the form below to register.";s:3:"css";s:0:"";s:15:"label_alignment";s:4:"left";}i:0;a:11:{s:6:"remove";s:1:"0";s:2:"id";s:1:"0";s:4:"type";s:8:"username";s:4:"meta";s:1:"0";s:8:"required";s:1:"1";s:5:"label";s:8:"Username";s:15:"validation_rule";s:0:"";s:4:"desc";s:0:"";s:11:"placeholder";s:0:"";s:18:"validation_message";s:0:"";s:3:"css";s:0:"";}i:1;a:12:{s:6:"remove";s:1:"0";s:2:"id";s:1:"1";s:4:"type";s:5:"email";s:4:"meta";s:1:"0";s:8:"required";s:1:"1";s:5:"label";s:6:"E-mail";s:15:"validation_rule";s:5:"email";s:6:"label2";s:14:"Confirm E-mail";s:4:"desc";s:0:"";s:11:"placeholder";s:0:"";s:18:"validation_message";s:0:"";s:3:"css";s:0:"";}i:2;a:15:{s:6:"remove";s:1:"0";s:2:"id";s:1:"2";s:4:"type";s:8:"password";s:4:"meta";s:1:"0";s:8:"required";s:1:"1";s:5:"label";s:8:"Password";s:15:"validation_rule";s:0:"";s:6:"label2";s:16:"Confirm Password";s:4:"desc";s:0:"";s:11:"placeholder";s:0:"";s:18:"validation_message";s:0:"";s:3:"css";s:0:"";s:10:"show_meter";s:1:"1";s:17:"restrict_strength";s:1:"1";s:16:"strength_message";s:13:"Weak Password";}i:3;a:4:{s:2:"id";s:1:"3";s:4:"type";s:7:"captcha";s:5:"label";s:10:"Re-Captcha";s:14:"recaptcha_skin";s:3:"red";}s:6:"submit";a:11:{s:5:"label";s:6:"Submit";s:4:"type";s:6:"submit";s:6:"remove";s:1:"0";s:4:"meta";s:1:"0";s:4:"text";s:6:"Submit";s:5:"reset";s:1:"0";s:10:"reset_text";s:5:"Reset";s:12:"confirmation";s:4:"text";s:12:"redirect_url";s:0:"";s:4:"page";s:1:"7";s:7:"message";s:31:"Thank you for your registration";}}";', 'yes'),
(490, 'pie_fields_default', 'a:5:{s:4:"form";a:7:{s:5:"label";s:17:"Registration Form";s:4:"desc";s:39:"Please fill the form below to register.";s:15:"label_alignment";s:4:"left";s:3:"css";s:0:"";s:4:"type";s:4:"form";s:4:"meta";i:0;s:5:"reset";i:0;}i:0;a:11:{s:5:"label";s:8:"Username";s:4:"type";s:8:"username";s:2:"id";i:0;s:6:"remove";i:0;s:8:"required";i:1;s:4:"desc";s:0:"";s:6:"length";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:3:"css";s:0:"";s:4:"meta";i:0;}i:1;a:13:{s:5:"label";s:6:"E-mail";s:6:"label2";s:14:"Confirm E-mail";s:4:"type";s:5:"email";s:2:"id";i:1;s:6:"remove";i:0;s:8:"required";i:1;s:4:"desc";s:0:"";s:6:"length";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:3:"css";s:0:"";s:15:"validation_rule";s:5:"email";s:4:"meta";i:0;}i:2;a:14:{s:5:"label";s:8:"Password";s:6:"label2";s:16:"Confirm Password";s:4:"type";s:8:"password";s:2:"id";i:2;s:6:"remove";i:0;s:8:"required";i:1;s:4:"desc";s:0:"";s:6:"length";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:3:"css";s:0:"";s:15:"validation_rule";s:0:"";s:4:"meta";i:0;s:10:"show_meter";i:1;}s:6:"submit";a:7:{s:7:"message";s:31:"Thank you for your registration";s:12:"confirmation";s:4:"text";s:4:"text";s:6:"Submit";s:5:"reset";i:0;s:10:"reset_text";s:5:"Reset";s:4:"type";s:6:"submit";s:4:"meta";i:0;}}', 'yes') ;
INSERT INTO `dh_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(491, 'pie_fields_meta', 'a:32:{s:4:"text";s:2327:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="length_%d%">Length</label><input type="text" name="field[%d%][length]" id="length_%d%" class="input_fields character_fields field_length numeric"></div><div class="advance_fields"><label>Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="default_value_%d%">Default Value</label><input type="text" name="field[%d%][default_value]" id="default_value_%d%" class="input_fields field_default_value"></div><div class="advance_fields"><label for="placeholder_%d%">Placeholder</label><input type="text" name="field[%d%][placeholder]" id="placeholder_%d%" class="input_fields field_placeholder"></div><div class="advance_fields"><label for="validation_rule_%d%">Validation Rule</label><select name="field[%d%][validation_rule]" id="validation_rule_%d%"><option>None</option><option value="number">Number</option><option value="alphanumeric">Alphanumeric</option><option value="email">E-mail</option><option value="website">Website</option><option value="standard">USA Format (xxx) (xxx-xxxx)</option><option value="international">Phone International xxx-xxx-xxxx</option></select></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:8:"username";s:1203:"<input type="hidden" value="0" class="input_fields" name="field[%d%][meta]" id="meta_%d%"><div class="fields_main"><div class="advance_options_fields"><input type="hidden" value="1" name="field[%d%][required]"><input type="hidden" name="field[%d%][label]"><input type="hidden" name="field[%d%][validation_rule]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" value="Username" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="placeholder_%d%">Placeholder</label><input type="text" name="field[%d%][placeholder]" id="placeholder_%d%" class="input_fields field_placeholder"></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div></div></div>";s:7:"default";s:301:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" class="input_fields" name="field[%d%][type]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div></div></div>";s:3:"aim";s:313:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" class="input_fields" name="field[%d%][type]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" value="AIM" id="label_%d%" class="input_fields field_label"></div></div></div>";s:3:"url";s:317:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" class="input_fields" name="field[%d%][type]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" value="Website" class="input_fields field_label"></div></div></div>";s:3:"yim";s:318:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" class="input_fields" name="field[%d%][type]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" value="Yahoo IM" class="input_fields field_label"></div></div></div>";s:11:"description";s:324:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" class="input_fields" name="field[%d%][type]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" value="About Yourself" class="input_fields field_label"></div></div></div>";s:6:"jabber";s:330:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" class="input_fields" name="field[%d%][type]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" value="Jabber / Google Talk" id="label_%d%" class="input_fields field_label"></div></div></div>";s:8:"password";s:2234:"<div class="fields_main"><input type="hidden" value="0" class="input_fields" name="field[%d%][meta]" id="meta_%d%"><div class="advance_options_fields"><input type="hidden" value="1" name="field[%d%][required]"><input type="hidden" name="field[%d%][label]"><input type="hidden" name="field[%d%][validation_rule]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" value="Password" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="label2_%d%">Label2</label><input type="text" name="field[%d%][label2]" value="Confirm Password" id="label2_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="placeholder_%d%">Placeholder</label><input type="text" name="field[%d%][placeholder]" id="placeholder_%d%" class="input_fields field_placeholder"></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_meter_%d%">Show Strength Meter</label><select class="show_meter" name="field[%d%][show_meter]" id="show_meter_%d%" class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div><div class="advance_fields"><label for="restrict_strength_%d%">Minimum Strength</label><select class="show_meter" name="field[%d%][restrict_strength]" id="restrict_strength_%d%"><option value="1" selected="selected">Very weak</option><option value="2">Weak</option><option value="3">Medium</option><option value="4">Strong</option></select></div><div class="advance_fields"><label for="strength_message_%d%">Strength Message</label><input type="text" name="field[%d%][strength_message]" id="strength_message_%d%" class="input_fields" value="Weak Password"></div></div></div>";s:5:"email";s:1588:"<input type="hidden" value="0" class="input_fields" name="field[%d%][meta]" id="meta_%d%"><div class="fields_main"><div class="advance_options_fields"><input type="hidden" value="1" name="field[%d%][required]"><input type="hidden" name="field[%d%][label]"><input type="hidden" name="field[%d%][validation_rule]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" value="E-mail" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="label2_%d%">Label2</label><input type="text" name="field[%d%][label2]" value="Confrim E-mail" id="label2_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="confirm_email_%d%">Confirm E-Mail</label><input name="field[%d%][confirm_email]" id="confirm_email" value="%d%" type="checkbox" class="checkbox_fields"></div><div class="advance_fields"><label for="placeholder_%d%">Placeholder</label><input type="text" name="field[%d%][placeholder]" id="placeholder_%d%" class="input_fields field_placeholder"></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div></div></div>";s:8:"textarea";s:2038:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="rows_%d%">Rows</label><input type="text" value="8" name="field[%d%][rows]" id="rows_%d%" class="input_fields character_fields field_rows numeric"></div><div class="advance_fields"><label for="cols_%d%">Columns</label><input type="text" value="73" name="field[%d%][cols]" id="cols_%d%" class="input_fields character_fields field_cols numeric"></div><div class="advance_fields"><label>Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="default_value_%d%">Default Value</label><input type="text" name="field[%d%][default_value]" id="default_value_%d%" class="input_fields field_default_value"></div><div class="advance_fields"><label for="placeholder_%d%">Placeholder</label><input type="text" name="field[%d%][placeholder]" id="placeholder_%d%" class="input_fields field_placeholder"></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:8:"dropdown";s:2286:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields  sel_options_%d%"><label for="display_%d%">Display Value</label><input type="text" name="field[%d%][display][]" id="display_%d%" class="input_fields character_fields select_option_display"><label for="value_%d%">Value</label><input type="text" name="field[%d%][value][]" id="value_%d%" class="input_fields character_fields select_option_value"><label>Checked</label><input type="radio" value="0" id="check_%d%" name="field[%d%][selected][]" class="select_option_checked"><a style="color:white" href="javascript:;" onclick="addOptions(%d%,\'radio\',jQuery(this));">+</a><!--<a style="color:white;font-size: 13px;margin-left: 2px;" href="javascript:;" onclick="jQuery(this).parent().remove();">x</a>--></div><div class="advance_fields"><label>Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"> <label for="list_type_%d%">List Type</label><select name="field[%d%][list_type]" id="list_type_%d%"><option>None</option><option value="country">Country</option><option value="us_states">US States</option><option value="can_states">Canada States</option> </select></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:11:"multiselect";s:2291:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields  sel_options_%d%"><label for="display_%d%">Display Value</label><input type="text" name="field[%d%][display][]" id="display_%d%" class="input_fields character_fields select_option_display"><label for="value_%d%">Value</label><input type="text" name="field[%d%][value][]" id="value_%d%" class="input_fields character_fields select_option_value"><label>Checked</label><input type="checkbox" value="0" id="check_%d%" name="field[%d%][selected][]" class="select_option_checked"><a style="color:white" href="javascript:;" onclick="addOptions(%d%,\'checkbox\',jQuery(this));">+</a><!--<a style="color:white;font-size: 13px;margin-left: 2px;" href="javascript:;" onclick="jQuery(this).parent().remove();">x</a>--></div><div class="advance_fields"><label>Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"> <label for="list_type_%d%">List Type</label><select name="field[%d%][list_type]" id="list_type_%d%"><option>None</option><option value="country">Country</option><option value="us_states">US States</option><option value="can_states">Canada States</option></select></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:6:"number";s:1986:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="min_%d%">Min</label><input type="text" name="field[%d%][min]" id="min_%d%" class="input_fields character_fields  numeric"></div><div class="advance_fields"><label for="max_%d%">Max</label><input type="text" name="field[%d%][max]" id="max_%d%" class="input_fields character_fields  numeric"></div><div class="advance_fields"><label>Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="default_value_%d%">Default Value</label><input type="text" name="field[%d%][default_value]" id="default_value_%d%" class="input_fields field_default_value"></div><div class="advance_fields"><label for="placeholder_%d%">Placeholder</label><input type="text" name="field[%d%][placeholder]" id="placeholder_%d%" class="input_fields field_placeholder"></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:8:"checkbox";s:1861:"<div class="fields_main">  <div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div>  <div class="advance_fields  sel_options_%d%"><label for="display_%d%">Display Value</label><input type="text" name="field[%d%][display][]" id="display_%d%" class="input_fields character_fields checkbox_option_display"><label for="value_%d%">Value</label><input type="text" name="field[%d%][value][]" id="value_%d%" class="input_fields character_fields checkbox_option_value"><label>Checked</label><input type="checkbox" value="0" id="check_%d%" name="field[%d%][selected][]" class="checkbox_option_checked"><a style="color:white" href="javascript:;" onClick="addOptions(%d%,\'checkbox\');">+</a></div><div class="advance_fields"><label>Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div> <div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div> </div></div>";s:5:"radio";s:1840:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields  sel_options_%d%"><label for="display_%d%">Display Value</label><input type="text" name="field[%d%][display][]" id="display_%d%" class="input_fields character_fields radio_option_display"><label for="value_%d%">Value</label><input type="text" name="field[%d%][value][]" id="value_%d%" class="input_fields character_fields radio_option_value"><label>Checked</label><input type="radio" value="0" id="check_%d%" name="field[%d%][selected][]" class="radio_option_checked"><a style="color:white" href="javascript:;" onclick="addOptions(%d%,\'radio\');">+</a></div><div class="advance_fields"><label>Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:4:"html";s:457:"<input type="hidden" value="0" class="input_fields" name="field[%d%][meta]" id="meta_%d%"><div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><textarea rows="8" id="htmlbox_%d%" class="ckeditor" name="field[%d%][html]" cols="16"></textarea></div></div></div>";s:12:"sectionbreak";s:325:"<input type="hidden" value="0" class="input_fields" name="field[%d%][meta]" id="meta_%d%"><div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div></div></div>";s:9:"pagebreak";s:2079:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" value="0" class="input_fields" name="field[%d%][meta]" id="meta_%d%"><div class="advance_fields"><label for="next_button_%d%">Next Button</label><div class="calendar_icon_type">  <input class="next_button" type="radio" id="next_button_%d%_text" name="field[%d%][next_button]" value="text" checked="checked">  <label for="next_button_%d%_text">Text </label>  <input class="next_button" type="radio" id="next_button_%d%_url" name="field[%d%][next_button]" value="url"><label for="next_button_%d%_url"> Image</label></div><div id="next_button_url_container_%d%" style="float:left;clear: both;display: none;">  <label for="next_button_%d%_url"> Image Path: </label>  <input type="text" name="field[%d%][next_button_url]" class="input_fields" id="next_button_%d%_url"></div><div id="next_button_text_container_%d%" style="float:left;clear: both;">  <label for="next_button_%d%_text"> Text: </label>  <input type="text" name="field[%d%][next_button_text]" value="Next" class="input_fields" id="next_button_%d%_text"></div></div><div class="advance_fields"><label for="prev_button_%d%">Previous Button</label><div class="calendar_icon_type">  <input class="prev_button" type="radio" id="prev_button_%d%_text" name="field[%d%][prev_button]" value="text" checked="checked">  <label for="prev_button_%d%_text">Text </label>  <input class="prev_button" type="radio" id="prev_button_%d%_url" name="field[%d%][prev_button]" value="url">  <label for="prev_button_%d%_url"> Image</label></div><div id="prev_button_url_container_%d%" style="float:left;clear: both;display: none;">  <label for="prev_button_%d%_url"> Image Path: </label>  <input type="text" name="field[%d%][prev_button_url]" class="input_fields" id="prev_button_%d%_url"></div><div id="prev_button_text_container_%d%" style="float:left;clear: both;">  <label for="prev_button_%d%_text"> Text: </label>  <input type="text" name="field[%d%][prev_button_text]" value="Previous" class="input_fields" id="prev_button_%d%_text"></div></div></div></div>";s:4:"name";s:1479:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" value="First Name" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="label2_%d%">Label2</label><input type="text" name="field[%d%][label2]" value="Last Name" id="label2_%d%" class="input_fields field_label2"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="required_%d%">Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:4:"time";s:1490:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"> <label for="time_type_%d%">List Type</label><select class="time_format" name="field[%d%][time_type]" id="time_type_%d%"><option value="12">12 hour</option><option value="24">24 hour</option></select></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label>Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:7:"website";s:961:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label>Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div></div></div>";s:6:"upload";s:1593:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" class="input_fields" name="field[%d%][type]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" value="Upload" class="input_fields field_label"></div><div class="advance_fields"><label for="file_types_%d%">File Types</label><input type="text" name="field[%d%][file_types]" id="file_types_%d%" class="input_fields"><a class="info" href="javascript:;">Separated with commas (i.e. jpg, gif, png, pdf)</a></div><div clss="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label>Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:11:"profile_pic";s:1345:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" class="input_fields" name="field[%d%][type]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" value="Profile Picture" class="input_fields field_label"></div><div clss="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label>Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:7:"address";s:14875:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"> <label for="address_type_%d%">List Type</label><select class="address_type" name="field[%d%][address_type]" id="address_type_%d%"><option value="International">International</option><option value="United States">United States</option><option value="Canada">Canada</option></select></div><div id="default_country_div_%d%" class="advance_fields"> <label for="default_country_%d%">Default Country</label><select class="default_country" name="field[%d%][default_country]" id="default_country_%d%"><option value="" selected="selected"></option><option value="Afghanistan">Afghanistan</option><option value="Albania">Albania</option><option value="Algeria">Algeria</option><option value="American Samoa">American Samoa</option><option value="Andorra">Andorra</option><option value="Angola">Angola</option><option value="Antigua and Barbuda">Antigua and Barbuda</option><option value="Argentina">Argentina</option><option value="Armenia">Armenia</option><option value="Australia">Australia</option><option value="Austria">Austria</option><option value="Azerbaijan">Azerbaijan</option><option value="Bahamas">Bahamas</option><option value="Bahrain">Bahrain</option><option value="Bangladesh">Bangladesh</option><option value="Barbados">Barbados</option><option value="Belarus">Belarus</option><option value="Belgium">Belgium</option><option value="Belize">Belize</option><option value="Benin">Benin</option><option value="Bermuda">Bermuda</option><option value="Bhutan">Bhutan</option><option value="Bolivia">Bolivia</option><option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option><option value="Botswana">Botswana</option><option value="Brazil">Brazil</option><option value="Brunei">Brunei</option><option value="Bulgaria">Bulgaria</option><option value="Burkina Faso">Burkina Faso</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="Canada">Canada</option><option value="Cape Verde">Cape Verde</option><option value="Central African Republic">Central African Republic</option><option value="Chad">Chad</option><option value="Chile">Chile</option><option value="China">China</option><option value="Colombia">Colombia</option><option value="Comoros">Comoros</option><option value="Congo">Congo</option><option value="Costa Rica">Costa Rica</option><option value="Costa Rica">Costa Rica</option><option value="Côte d\'Ivoire">Côte d\\\'Ivoire</option><option value="Croatia">Croatia</option><option value="Cuba">Cuba</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Denmark">Denmark</option><option value="Djibouti">Djibouti</option><option value="Dominica">Dominica</option><option value="Dominican Republic">Dominican Republic</option><option value="East Timor">East Timor</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Greece">Greece</option><option value="Greenland">Greenland</option><option value="Grenada">Grenada</option><option value="Guam">Guam</option><option value="Guatemala">Guatemala</option><option value="Guinea">Guinea</option><option value="Guinea-Bissau">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Honduras">Honduras</option><option value="Hong Kong">Hong Kong</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iran">Iran</option><option value="Iraq">Iraq</option><option value="Ireland">Ireland</option><option value="Israel">Israel</option><option value="Italy">Italy</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kiribati">Kiribati</option><option value="North Korea">North Korea</option><option value="South Korea">South Korea</option><option value="Kuwait">Kuwait</option><option value="Kyrgyzstan">Kyrgyzstan</option><option value="Laos">Laos</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Libya">Libya</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Macedonia">Macedonia</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia">Malaysia</option><option value="Maldives">Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Marshall Islands">Marshall Islands</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mexico">Mexico</option><option value="Micronesia">Micronesia</option><option value="Moldova">Moldova</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="Montenegro">Montenegro</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="Myanmar">Myanmar</option><option value="Namibia">Namibia</option><option value="Nauru">Nauru</option><option value="Nepal">Nepal</option><option value="Netherlands">Netherlands</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Norway">Norway</option><option value="Northern Mariana Islands">Northern Mariana Islands</option><option value="Oman">Oman</option><option value="Pakistan">Pakistan</option><option value="Palau">Palau</option><option value="Palestine">Palestine</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Puerto Rico">Puerto Rico</option><option value="Qatar">Qatar</option><option value="Romania">Romania</option><option value="Russia">Russia</option><option value="Rwanda">Rwanda</option><option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option><option value="Saint Lucia">Saint Lucia</option><option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option><option value="Samoa">Samoa</option><option value="San Marino">San Marino</option><option value="Sao Tome and Principe">Sao Tome and Principe</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia and Montenegro">Serbia and Montenegro</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="Slovakia">Slovakia</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="Somalia">Somalia</option><option value="South Africa">South Africa</option><option value="Spain">Spain</option><option value="Sri Lanka">Sri Lanka</option><option value="Sudan">Sudan</option><option value="Sudan, South">Sudan, South</option><option value="Suriname">Suriname</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syria">Syria</option><option value="Taiwan">Taiwan</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania">Tanzania</option><option value="Thailand">Thailand</option><option value="Togo">Togo</option><option value="Tonga">Tonga</option><option value="Trinidad and Tobago">Trinidad and Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Tuvalu">Tuvalu</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United Kingdom">United Kingdom</option><option value="United States">United States</option><option value="Uruguay">Uruguay</option><option value="Uzbekistan">Uzbekistan</option><option value="Vanuatu">Vanuatu</option><option value="Vatican City">Vatican City</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Virgin Islands, British">Virgin Islands, British</option><option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option><option value="Yemen">Yemen</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option></select></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="required_%d%">Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="hide_address2_%d%">Hide Address 2</label><input onchange="checkEvents(this,\'address_address2_%d%\')" name="field[%d%][hide_address2]" id="hide_address2_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="hide_address2_%d%" class="required"></label></div><div class="advance_fields"><label for="hide_state_%d%">Hide State</label><input class="hide_state" name="field[%d%][hide_state]" id="hide_state_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="hide_state_%d%" class="required"></label></div><div style="display:none;" id="default_state_div_%d%" class="advance_fields"><label for="default_state_%d%">Default State</label><select id="us_states_%d%" style="display:none;" class="default_state us_states_%d%" name="field[%d%][us_default_state]"><option value="" selected="selected"></option><option value="Alabama">Alabama</option><option value="Alaska">Alaska</option><option value="Arizona">Arizona</option><option value="Arkansas">Arkansas</option><option value="California">California</option><option value="Colorado">Colorado</option><option value="Connecticut">Connecticut</option><option value="Delaware">Delaware</option><option value="District of Columbia">District of Columbia</option><option value="Florida">Florida</option><option value="Georgia">Georgia</option><option value="Hawaii">Hawaii</option><option value="Idaho">Idaho</option><option value="Illinois">Illinois</option><option value="Indiana">Indiana</option><option value="Iowa">Iowa</option><option value="Kansas">Kansas</option><option value="Kentucky">Kentucky</option><option value="Louisiana">Louisiana</option><option value="Maine">Maine</option><option value="Maryland">Maryland</option><option value="Massachusetts">Massachusetts</option><option value="Michigan">Michigan</option><option value="Minnesota">Minnesota</option><option value="Mississippi">Mississippi</option><option value="Missouri">Missouri</option><option value="Montana">Montana</option><option value="Nebraska">Nebraska</option><option value="Nevada">Nevada</option><option value="New Hampshire">New Hampshire</option><option value="New Jersey">New Jersey</option><option value="New Mexico">New Mexico</option><option value="New York">New York</option><option value="North Carolina">North Carolina</option><option value="North Dakota">North Dakota</option><option value="Ohio">Ohio</option><option value="Oklahoma">Oklahoma</option><option value="Oregon">Oregon</option><option value="Pennsylvania">Pennsylvania</option><option value="Rhode Island">Rhode Island</option><option value="South Carolina">South Carolina</option><option value="South Dakota">South Dakota</option><option value="Tennessee">Tennessee</option><option value="Texas">Texas</option><option value="Utah">Utah</option><option value="Vermont">Vermont</option><option value="Virginia">Virginia</option><option value="Washington">Washington</option><option value="West Virginia">West Virginia</option><option value="Wisconsin">Wisconsin</option><option value="Wyoming">Wyoming</option><option value="Armed Forces Americas">Armed Forces Americas</option><option value="Armed Forces Europe">Armed Forces Europe</option><option value="Armed Forces Pacific">Armed Forces Pacific</option></select><select id="can_states_%d%" style="display:none;" class="default_state can_states_%d%" name="field[%d%][canada_default_state]"><option value="" selected="selected"></option><option value="Alberta">Alberta</option><option value="British Columbia">British Columbia</option><option value="Manitoba">Manitoba</option><option value="New Brunswick">New Brunswick</option><option value="Newfoundland &amp; Labrador">Newfoundland and Labrador</option><option value="Northwest Territories">Northwest Territories</option><option value="Nova Scotia">Nova Scotia</option><option value="Nunavut">Nunavut</option><option value="Ontario">Ontario</option><option value="Prince Edward Island">Prince Edward Island</option><option value="Quebec">Quebec</option><option value="Saskatchewan">Saskatchewan</option><option value="Yukon">Yukon</option></select></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:7:"captcha";s:700:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" class="input_fields" name="field[%d%][type]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" value="Re-Captcha" class="input_fields field_label"></div><div class="advance_fields"><label for="recaptcha_skin_%d%">Captcha Skin</label><select class="show_in_profile" name="field[%d%][recaptcha_skin]" id="recaptcha_skin_%d%"  class="checkbox_fields"><option value="red" selected="selected">Red</option><option value="white">White</option><option value="clean">Clean</option><option value="blackglass">Blackglass</option></select></div></div></div>";s:12:"math_captcha";s:1015:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" value="1" name="field[%d%][required]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" value="Math Captcha" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="placeholder_%d%">Placeholder</label><input type="text" name="field[%d%][placeholder]" id="placeholder_%d%" class="input_fields field_placeholder"></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div></div></div>";s:5:"phone";s:1852:"<div class="fields_main"><div class="advance_options_fields"><input type="hidden" class="input_fields" name="field[%d%][type]"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="required_%d%">Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="default_value_%d%">Default Value</label><input type="text" name="field[%d%][default_value]" id="default_value_%d%" class="input_fields field_default_value"></div><div class="advance_fields"> <label for="phone_format_%d%">Phone Format</label><select class="phone_format" name="field[%d%][phone_format]" id="phone_format_%d%"><option value="standard">USA Format (xxx) (xxx-xxxx)</option><option value="international">Phone International xxx-xxx-xxxx</option></select></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:4:"date";s:3472:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="required_%d%">Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="date_type_%d%">Date Format</label><select class="date_format" name="field[%d%][date_format]" id="date_format_%d%"><option value="mm/dd/yy">mm/dd/yy</option><option value="dd/mm/yy">dd/mm/yy</option><option value="dd-mm-yy">dd-mm-yy</option><option value="dd.mm.yy">dd.mm.yy</option><option value="yy/mm/dd">yy/mm/dd</option><option value="yy.mm.dd">yy.mm.dd</option></select></div><div class="advance_fields"><label for="date_type_%d%">Date Input Type</label><select class="date_type" name="field[%d%][date_type]" id="date_type_%d%"><option value="datefield">Date Field</option><option value="datepicker">Date Picker</option><option value="datedropdown">Date Drop Down</option></select></div><div class="advance_fields"><label for="startingDate_%d%">Starting Date</label><input name="field[%d%][startingDate]" id="startingDate_%d%" type="text" value="1901" class="input_fields"><a href="javascript:;" class="info">e.g : 1901</a></div><div class="advance_fields"><label for="endingDate_%d%">Ending Date</label><input name="field[%d%][endingDate]" id="endingDate_%d%" type="text" class="input_fields" value="2014"><a href="javascript:;" class="info">e.g : 2014</a></div><div style="display:none;" id="icon_div_%d%" class="advance_fields"><label for="date_type_%d%">&nbsp;</label><div class="calendar_icon_type"><input class="calendar_icon" type="radio" id="calendar_icon_%d%_none" name="field[%d%][calendar_icon]" value="none" checked="checked"><label for="calendar_icon_%d%_none"> No Icon </label>&nbsp;&nbsp;<input class="calendar_icon" type="radio" id="calendar_icon_%d%_calendar" name="field[%d%][calendar_icon]" value="calendar"><label for="calendar_icon_%d%_calendar"> Calendar Icon </label>&nbsp;&nbsp;<input class="calendar_icon" type="radio" id="calendar_icon_%d%_custom" name="field[%d%][calendar_icon]" value="custom"><label for="calendar_icon_%d%_custom"> Custom Icon </label></div><div id="icon_url_container_%d%" style="display: none;float:left;clear: both;"><label for="cfield_calendar_icon_%d%_url"> Image Path: </label><input type="text" class="input_fields" name="field[%d%][calendar_icon_url]" id="cfield_calendar_icon_%d%_url"></div></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:4:"list";s:1684:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="required_%d%">Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="rows_%d%">Rows</label><input type="text" value="1" name="field[%d%][rows]" id="rows_%d%" class="input_fields character_fields list_rows numeric greaterzero"></div><div class="advance_fields"><label for="cols_%d%">Columns</label><input type="text" value="1" name="field[%d%][cols]" id="cols_%d%" class="input_fields character_fields list_cols numeric greaterzero"></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div><div class="advance_fields"><label for="show_in_profile_%d%">Show in Profile</label><select class="show_in_profile" name="field[%d%][show_in_profile]" id="show_in_profile_%d%"  class="checkbox_fields"><option value="1" selected="selected">Yes</option><option value="0">No</option></select></div></div></div>";s:6:"hidden";s:437:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="default_value_%d%">Default Value</label><input type="text" name="field[%d%][default_value]" id="default_value_%d%" class="input_fields field_default_value"></div></div></div>";s:10:"invitation";s:1172:"<div class="fields_main"><div class="advance_options_fields"><div class="advance_fields"><label for="label_%d%">Label</label><input type="text" name="field[%d%][label]" id="label_%d%" class="input_fields field_label"></div><div class="advance_fields"><label for="desc_%d%">Description</label><textarea name="field[%d%][desc]" id="desc_%d%" rows="8" cols="16"></textarea></div><div class="advance_fields"><label for="required_%d%">Rules</label><input name="field[%d%][required]" id="required_%d%" value="%d%" type="checkbox" class="checkbox_fields"><label for="required_%d%" class="required">Required</label></div><div class="advance_fields"><label for="placeholder_%d%">Placeholder</label><input type="text" name="field[%d%][placeholder]" id="placeholder_%d%" class="input_fields field_placeholder"></div><div class="advance_fields"><label for="validation_message_%d%">Validation Message</label><input type="text" name="field[%d%][validation_message]" id="validation_message_%d%" class="input_fields"></div><div class="advance_fields"><label for="css_%d%">CSS Class Name</label><input type="text" name="field[%d%][css]" id="css_%d%" class="input_fields"></div></div></div>";}', 'yes') ;
INSERT INTO `dh_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(493, 'piereg_math_cpatcha_enable', 'false', 'yes'),
(540, '_wc_session_32856f2e9bc86dadd87c28f258e1111d', 'a:1:{s:4:"cart";s:313:"a:1:{s:32:"6f4922f45568161a8cdf4ad2299f6d23";a:9:{s:10:"product_id";i:18;s:12:"variation_id";s:0:"";s:9:"variation";s:0:"";s:8:"quantity";i:2;s:10:"line_total";d:29110;s:8:"line_tax";i:0;s:13:"line_subtotal";i:29110;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}}";}', 'no'),
(541, '_wc_session_expires_32856f2e9bc86dadd87c28f258e1111d', '1416476516', 'no'),
(542, '_wc_session_a54ee1522361a318f748ab69c3348c6c', 'a:1:{s:4:"cart";s:313:"a:1:{s:32:"6f4922f45568161a8cdf4ad2299f6d23";a:9:{s:10:"product_id";i:18;s:12:"variation_id";s:0:"";s:9:"variation";s:0:"";s:8:"quantity";i:2;s:10:"line_total";d:29110;s:8:"line_tax";i:0;s:13:"line_subtotal";i:29110;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}}";}', 'no'),
(543, '_wc_session_expires_a54ee1522361a318f748ab69c3348c6c', '1416477085', 'no'),
(546, '_wc_session_c87bebf663220350502ba5d62965c0f7', 'a:1:{s:4:"cart";s:313:"a:1:{s:32:"6f4922f45568161a8cdf4ad2299f6d23";a:9:{s:10:"product_id";i:18;s:12:"variation_id";s:0:"";s:9:"variation";s:0:"";s:8:"quantity";i:2;s:10:"line_total";d:29110;s:8:"line_tax";i:0;s:13:"line_subtotal";i:29110;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}}";}', 'no'),
(547, '_wc_session_expires_c87bebf663220350502ba5d62965c0f7', '1416477322', 'no'),
(550, '_wc_session_a6c7daa74c36fdd5fce48e30e81510c7', 'a:1:{s:4:"cart";s:313:"a:1:{s:32:"6f4922f45568161a8cdf4ad2299f6d23";a:9:{s:10:"product_id";i:18;s:12:"variation_id";s:0:"";s:9:"variation";s:0:"";s:8:"quantity";i:2;s:10:"line_total";d:29110;s:8:"line_tax";i:0;s:13:"line_subtotal";i:29110;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}}";}', 'no'),
(551, '_wc_session_expires_a6c7daa74c36fdd5fce48e30e81510c7', '1416477514', 'no'),
(575, '_wc_session_99ee521f7bd4d38231a20da2725a2862', 'a:1:{s:4:"cart";s:313:"a:1:{s:32:"6f4922f45568161a8cdf4ad2299f6d23";a:9:{s:10:"product_id";i:18;s:12:"variation_id";s:0:"";s:9:"variation";s:0:"";s:8:"quantity";i:2;s:10:"line_total";d:29110;s:8:"line_tax";i:0;s:13:"line_subtotal";i:29110;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}}";}', 'no'),
(576, '_wc_session_expires_99ee521f7bd4d38231a20da2725a2862', '1416574291', 'no') ;

#
# End of data contents of table `dh_options`
# --------------------------------------------------------



#
# Delete any existing table `dh_pieregister_code`
#

DROP TABLE IF EXISTS `dh_pieregister_code`;


#
# Table structure of table `dh_pieregister_code`
#

CREATE TABLE `dh_pieregister_code` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `created` date NOT NULL,
  `modified` date NOT NULL,
  `name` text NOT NULL,
  `count` int(5) NOT NULL,
  `status` int(2) NOT NULL,
  `code_usage` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


#
# Data contents of table `dh_pieregister_code`
#

#
# End of data contents of table `dh_pieregister_code`
# --------------------------------------------------------



#
# Delete any existing table `dh_postmeta`
#

DROP TABLE IF EXISTS `dh_postmeta`;


#
# Table structure of table `dh_postmeta`
#

CREATE TABLE `dh_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_postmeta`
#
INSERT INTO `dh_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_menu_item_type', 'custom'),
(3, 4, '_menu_item_menu_item_parent', '0'),
(4, 4, '_menu_item_object_id', '4'),
(5, 4, '_menu_item_object', 'custom'),
(6, 4, '_menu_item_target', ''),
(7, 4, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(8, 4, '_menu_item_xfn', ''),
(9, 4, '_menu_item_url', 'http://localhost/denimhouse/'),
(29, 7, '_edit_last', '1'),
(30, 7, '_edit_lock', '1414489372:1'),
(31, 7, '_wp_page_template', 'default'),
(32, 10, '_edit_last', '1'),
(33, 10, '_edit_lock', '1416401590:1'),
(34, 10, '_wp_page_template', 'default'),
(35, 12, '_menu_item_type', 'post_type'),
(36, 12, '_menu_item_menu_item_parent', '0'),
(37, 12, '_menu_item_object_id', '7'),
(38, 12, '_menu_item_object', 'page'),
(39, 12, '_menu_item_target', ''),
(40, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(41, 12, '_menu_item_xfn', ''),
(42, 12, '_menu_item_url', ''),
(44, 13, '_edit_last', '1'),
(45, 13, '_wp_page_template', 'default'),
(46, 13, '_edit_lock', '1414066689:1'),
(47, 15, '_menu_item_type', 'post_type'),
(48, 15, '_menu_item_menu_item_parent', '0'),
(49, 15, '_menu_item_object_id', '13'),
(50, 15, '_menu_item_object', 'page'),
(51, 15, '_menu_item_target', ''),
(52, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(53, 15, '_menu_item_xfn', ''),
(54, 15, '_menu_item_url', ''),
(56, 16, '_edit_last', '1'),
(57, 16, '_edit_lock', '1414066836:1'),
(58, 16, '_visibility', 'visible'),
(59, 16, '_stock_status', 'instock'),
(60, 16, 'total_sales', '0'),
(61, 16, '_downloadable', 'no'),
(62, 16, '_virtual', 'no'),
(63, 16, '_regular_price', '2000000'),
(64, 16, '_sale_price', '1600000'),
(65, 16, '_purchase_note', ''),
(66, 16, '_featured', 'no'),
(67, 16, '_weight', ''),
(68, 16, '_length', ''),
(69, 16, '_width', ''),
(70, 16, '_height', ''),
(71, 16, '_sku', 'DS0-3939-PL'),
(72, 16, '_product_attributes', 'a:0:{}'),
(73, 16, '_sale_price_dates_from', ''),
(74, 16, '_sale_price_dates_to', ''),
(75, 16, '_price', '1600000'),
(76, 16, '_sold_individually', ''),
(77, 16, '_manage_stock', 'no'),
(78, 16, '_backorders', 'no'),
(79, 16, '_stock', ''),
(80, 16, '_product_image_gallery', ''),
(81, 17, '_wp_attached_file', '2014/10/logo.jpg'),
(82, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1772;s:6:"height";i:1772;s:4:"file";s:16:"2014/10/logo.jpg";s:5:"sizes";a:1:{s:13:"wl_page_thumb";a:4:{s:4:"file";s:16:"logo-730x350.jpg";s:5:"width";i:730;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(83, 7, '_thumbnail_id', '17'),
(84, 19, '_wp_attached_file', '2014/10/1.jpg'),
(85, 19, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1333;s:6:"height";i:2000;s:4:"file";s:13:"2014/10/1.jpg";s:5:"sizes";a:11:{s:9:"thumbnail";a:4:{s:4:"file";s:13:"1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:13:"1-199x300.jpg";s:5:"width";i:199;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:14:"1-682x1024.jpg";s:5:"width";i:682;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:17:"home_slider_thumb";a:4:{s:4:"file";s:14:"1-1333x450.jpg";s:5:"width";i:1333;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:17:"home_portfo_thumb";a:4:{s:4:"file";s:13:"1-260x160.jpg";s:5:"width";i:260;s:6:"height";i:160;s:9:"mime-type";s:10:"image/jpeg";}s:15:"home_post_thumb";a:4:{s:4:"file";s:13:"1-340x210.jpg";s:5:"width";i:340;s:6:"height";i:210;s:9:"mime-type";s:10:"image/jpeg";}s:13:"wl_page_thumb";a:4:{s:4:"file";s:13:"1-730x350.jpg";s:5:"width";i:730;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:13:"blog_2c_thumb";a:4:{s:4:"file";s:13:"1-570x350.jpg";s:5:"width";i:570;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:11:"1-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:13:"1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:13:"1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:6.2999999999999998;s:6:"credit";s:0:"";s:6:"camera";s:17:"Canon EOS Kiss X3";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1382911038;s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"25";s:3:"iso";s:4:"3200";s:13:"shutter_speed";s:17:"0.066666666666667";s:5:"title";s:0:"";s:11:"orientation";i:1;}}'),
(86, 18, '_edit_last', '1'),
(87, 18, '_edit_lock', '1414570780:1'),
(88, 18, '_visibility', 'visible'),
(89, 18, '_stock_status', 'instock'),
(90, 18, 'total_sales', '0'),
(91, 18, '_downloadable', 'no'),
(92, 18, '_virtual', 'no'),
(93, 18, '_regular_price', '244444'),
(94, 18, '_sale_price', '14555'),
(95, 18, '_purchase_note', ''),
(96, 18, '_featured', 'no'),
(97, 18, '_weight', ''),
(98, 18, '_length', ''),
(99, 18, '_width', ''),
(100, 18, '_height', ''),
(101, 18, '_sku', '34rewre'),
(102, 18, '_product_attributes', 'a:0:{}'),
(103, 18, '_sale_price_dates_from', ''),
(104, 18, '_sale_price_dates_to', ''),
(105, 18, '_price', '14555'),
(106, 18, '_sold_individually', ''),
(107, 18, '_manage_stock', 'no'),
(108, 18, '_backorders', 'no'),
(109, 18, '_stock', ''),
(110, 18, '_product_image_gallery', '19'),
(111, 18, '_thumbnail_id', '19'),
(112, 20, '_edit_last', '1'),
(113, 20, '_wp_page_template', 'default'),
(114, 20, '_edit_lock', '1414638364:1'),
(115, 22, '_edit_last', '1'),
(116, 22, '_wp_page_template', 'default'),
(117, 22, '_edit_lock', '1414638431:1') ;

#
# End of data contents of table `dh_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `dh_posts`
#

DROP TABLE IF EXISTS `dh_posts`;


#
# Table structure of table `dh_posts`
#

CREATE TABLE `dh_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_posts`
#
INSERT INTO `dh_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2014-10-23 10:34:23', '2014-10-23 10:34:23', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-10-23 10:34:23', '2014-10-23 10:34:23', '', 0, 'http://localhost/denimhouse/?p=1', 0, 'post', '', 1),
(2, 1, '2014-10-23 10:34:23', '2014-10-23 10:34:23', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost/denimhouse/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-10-23 10:34:23', '2014-10-23 10:34:23', '', 0, 'http://localhost/denimhouse/?page_id=2', 0, 'page', '', 0),
(4, 1, '2014-10-23 10:57:19', '2014-10-23 10:57:19', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-10-23 12:21:28', '2014-10-23 12:21:28', '', 0, 'http://localhost/denimhouse/?p=4', 1, 'nav_menu_item', '', 0),
(7, 1, '2014-10-23 10:59:26', '2014-10-23 10:59:26', 'Denim house berdiri sejak tahun 2012. Denim  house didirikan denga tujuan memenuhi kebutuhan para konsumen pecinta denim.', 'About Us', '', 'publish', 'open', 'open', '', 'about-us', '', '', '2014-10-28 09:45:13', '2014-10-28 09:45:13', '', 0, 'http://localhost/denimhouse/?page_id=7', 0, 'page', '', 0),
(8, 1, '2014-10-23 10:59:26', '2014-10-23 10:59:26', '', 'About Us', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-10-23 10:59:26', '2014-10-23 10:59:26', '', 7, 'http://localhost/denimhouse/?p=8', 0, 'revision', '', 0),
(9, 1, '2014-10-23 11:59:16', '2014-10-23 11:59:16', 'Denim house berdiri sejak tahun 2012. Denim  house didirikan denga tujuan memenuhi kebutuhan para konsumen pecinta denim.', 'About Us', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-10-23 11:59:16', '2014-10-23 11:59:16', '', 7, 'http://localhost/denimhouse/?p=9', 0, 'revision', '', 0),
(10, 1, '2014-10-23 12:01:32', '2014-10-23 12:01:32', '<h2 style="text-align: center;">Welcome to Denim House</h2>\r\n<h2 style="text-align: center;">&amp;</h2>\r\n<h2 style="text-align: center;">Happy Shopping</h2>', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-10-23 12:01:32', '2014-10-23 12:01:32', '', 0, 'http://localhost/denimhouse/?page_id=10', 0, 'page', '', 0),
(11, 1, '2014-10-23 12:01:32', '2014-10-23 12:01:32', '<h2 style="text-align: center;">Welcome to Denim House</h2>\r\n<h2 style="text-align: center;">&amp;</h2>\r\n<h2 style="text-align: center;">Happy Shopping</h2>', 'Home', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-10-23 12:01:32', '2014-10-23 12:01:32', '', 10, 'http://localhost/denimhouse/?p=11', 0, 'revision', '', 0),
(12, 1, '2014-10-23 12:10:55', '2014-10-23 12:10:55', ' ', '', '', 'publish', 'open', 'open', '', '12', '', '', '2014-10-23 12:21:28', '2014-10-23 12:21:28', '', 0, 'http://localhost/denimhouse/?p=12', 3, 'nav_menu_item', '', 0),
(13, 1, '2014-10-23 12:20:28', '2014-10-23 12:20:28', '', 'Products', '', 'publish', 'open', 'open', '', 'products', '', '', '2014-10-23 12:20:28', '2014-10-23 12:20:28', '', 0, 'http://localhost/denimhouse/?page_id=13', 0, 'page', '', 0),
(14, 1, '2014-10-23 12:20:28', '2014-10-23 12:20:28', '', 'Products', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-23 12:20:28', '2014-10-23 12:20:28', '', 13, 'http://localhost/denimhouse/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2014-10-23 12:21:28', '2014-10-23 12:21:28', ' ', '', '', 'publish', 'open', 'open', '', '15', '', '', '2014-10-23 12:21:28', '2014-10-23 12:21:28', '', 0, 'http://localhost/denimhouse/?p=15', 2, 'nav_menu_item', '', 0),
(16, 1, '2014-10-23 12:22:58', '2014-10-23 12:22:58', '', 'Dry Navy', '', 'publish', 'open', 'closed', '', 'dry-navy', '', '', '2014-10-23 12:22:58', '2014-10-23 12:22:58', '', 0, 'http://localhost/denimhouse/?post_type=product&#038;p=16', 0, 'product', '', 0),
(17, 1, '2014-10-28 09:45:09', '2014-10-28 09:45:09', '', 'logo', '', 'inherit', 'open', 'open', '', 'logo', '', '', '2014-10-28 09:45:09', '2014-10-28 09:45:09', '', 7, 'http://localhost/denimhouse/wp-content/uploads/2014/10/logo.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2014-10-29 08:07:47', '2014-10-29 08:07:47', 'fdfdfd', 'Name 2', '', 'publish', 'open', 'closed', '', 'name-2', '', '', '2014-10-29 08:22:02', '2014-10-29 08:22:02', '', 0, 'http://localhost/denimhouse/?post_type=product&#038;p=18', 0, 'product', '', 0),
(19, 1, '2014-10-29 08:07:07', '2014-10-29 08:07:07', '', '1', '', 'inherit', 'open', 'open', '', '1', '', '', '2014-10-29 08:07:07', '2014-10-29 08:07:07', '', 18, 'http://localhost/denimhouse/wp-content/uploads/2014/10/1.jpg', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2014-10-30 03:08:25', '2014-10-30 03:08:25', '', 'Login', '', 'publish', 'open', 'open', '', 'login', '', '', '2014-10-30 03:08:25', '2014-10-30 03:08:25', '', 0, 'http://localhost/denimhouse/?page_id=20', 0, 'page', '', 0),
(21, 1, '2014-10-30 03:08:25', '2014-10-30 03:08:25', '', 'Login', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2014-10-30 03:08:25', '2014-10-30 03:08:25', '', 20, 'http://localhost/denimhouse/20-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2014-10-30 03:08:37', '2014-10-30 03:08:37', '', 'Register', '', 'publish', 'open', 'open', '', 'register', '', '', '2014-10-30 03:08:37', '2014-10-30 03:08:37', '', 0, 'http://localhost/denimhouse/?page_id=22', 0, 'page', '', 0),
(23, 1, '2014-10-30 03:08:37', '2014-10-30 03:08:37', '', 'Register', '', 'inherit', 'open', 'open', '', '22-revision-v1', '', '', '2014-10-30 03:08:37', '2014-10-30 03:08:37', '', 22, 'http://localhost/denimhouse/22-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2014-10-30 04:03:02', '2014-10-30 04:03:02', '[pie_register_login]', 'Pie Register - Login', '', 'publish', 'closed', 'closed', '', 'pie-register-login', '', '', '2014-10-30 04:03:02', '2014-10-30 04:03:02', '', 0, 'http://localhost/denimhouse/pie-register-login/', 0, 'page', '', 0),
(26, 1, '2014-10-30 04:03:02', '2014-10-30 04:03:02', '[pie_register_form]', 'Pie Register - Registration', '', 'publish', 'closed', 'closed', '', 'pie-register-registration', '', '', '2014-10-30 04:03:02', '2014-10-30 04:03:02', '', 0, 'http://localhost/denimhouse/pie-register-registration/', 0, 'page', '', 0),
(27, 1, '2014-10-30 04:03:02', '2014-10-30 04:03:02', '[pie_register_forgot_password]', 'Pie Register - Forgot Password', '', 'publish', 'closed', 'closed', '', 'pie-register-forgot-password', '', '', '2014-10-30 04:03:02', '2014-10-30 04:03:02', '', 0, 'http://localhost/denimhouse/pie-register-forgot-password/', 0, 'page', '', 0),
(28, 1, '2014-10-30 04:03:03', '2014-10-30 04:03:03', '[pie_register_profile]', 'Pie Register - Profile', '', 'publish', 'closed', 'closed', '', 'pie-register-profile', '', '', '2014-10-30 04:03:03', '2014-10-30 04:03:03', '', 0, 'http://localhost/denimhouse/pie-register-profile/', 0, 'page', '', 0),
(29, 1, '2014-11-18 09:28:11', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-11-18 09:28:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/denimhouse/?p=29', 0, 'post', '', 0) ;

#
# End of data contents of table `dh_posts`
# --------------------------------------------------------



#
# Delete any existing table `dh_term_relationships`
#

DROP TABLE IF EXISTS `dh_term_relationships`;


#
# Table structure of table `dh_term_relationships`
#

CREATE TABLE `dh_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_term_relationships`
#
INSERT INTO `dh_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(4, 13, 0),
(12, 13, 0),
(15, 13, 0),
(16, 2, 0),
(18, 2, 0) ;

#
# End of data contents of table `dh_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `dh_term_taxonomy`
#

DROP TABLE IF EXISTS `dh_term_taxonomy`;


#
# Table structure of table `dh_term_taxonomy`
#

CREATE TABLE `dh_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_term_taxonomy`
#
INSERT INTO `dh_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'product_type', '', 0, 2),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 0),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'shop_order_status', '', 0, 0),
(7, 7, 'shop_order_status', '', 0, 0),
(8, 8, 'shop_order_status', '', 0, 0),
(9, 9, 'shop_order_status', '', 0, 0),
(10, 10, 'shop_order_status', '', 0, 0),
(11, 11, 'shop_order_status', '', 0, 0),
(12, 12, 'shop_order_status', '', 0, 0),
(13, 13, 'nav_menu', '', 0, 3) ;

#
# End of data contents of table `dh_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `dh_terms`
#

DROP TABLE IF EXISTS `dh_terms`;


#
# Table structure of table `dh_terms`
#

CREATE TABLE `dh_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_terms`
#
INSERT INTO `dh_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'pending', 'pending', 0),
(7, 'failed', 'failed', 0),
(8, 'on-hold', 'on-hold', 0),
(9, 'processing', 'processing', 0),
(10, 'completed', 'completed', 0),
(11, 'refunded', 'refunded', 0),
(12, 'cancelled', 'cancelled', 0),
(13, 'Main Menu', 'main-menu', 0) ;

#
# End of data contents of table `dh_terms`
# --------------------------------------------------------



#
# Delete any existing table `dh_usermeta`
#

DROP TABLE IF EXISTS `dh_usermeta`;


#
# Table structure of table `dh_usermeta`
#

CREATE TABLE `dh_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_usermeta`
#
INSERT INTO `dh_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'dh_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'dh_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets'),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:11:{s:64:"3656c77f19630d2624d998d27a4f2af130a83f3f43cc9cb2456ad5a86fb6ea57";i:1416475687;s:64:"6fda1418d68e84eec2dcfe2b450eea277b06205fb502934217f44984e95e9479";i:1416475993;s:64:"58ba7eae8eed706f81026fefddbf2eb1497a498ffeb0294c5df6d4759b3c6760";i:1416476392;s:64:"c306e4a9f1491d00a63578d998a40e7afdc814d23c4bf3ed1748050e83c06cff";i:1416476422;s:64:"cda2c55601ee9e934b8b5e8ce7630ba22cdbde4c9c85d27bc80206d6ac0403f6";i:1416476516;s:64:"3f7616f293116efd24018685a6dc02e5bb59f42c5c825207f574db106a9e22f8";i:1416477085;s:64:"db35871ffa166ae9574e1249c4ae90e24bbafe470e6f3f6b687d90bec0ced375";i:1416477322;s:64:"f037cd995ce2bec139f6d41c40c7bbfc975a640caeba98f2804bd44f10059a9d";i:1416477514;s:64:"8fb715f4d6de2769aaa0af64b8a799da14d5731573d746398e6f2e187ee14cc5";i:1416477514;s:64:"bb99efe6cba876a580f0d255eea0082beeb33843abee6f5d40cd8f5dd2ce4701";i:1416574291;s:64:"f625c751398c0c36f04cd7361d32cb7a4af6d826dcef0b2b167e7ad64a0f2721";i:1416574291;}'),
(15, 1, 'dh_dashboard_quick_press_last_post_id', '29'),
(16, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(17, 1, 'metaboxhidden_nav-menus', 'a:5:{i:0;s:8:"add-post";i:1;s:11:"add-product";i:2;s:12:"add-post_tag";i:3;s:15:"add-product_cat";i:4;s:15:"add-product_tag";}'),
(18, 1, 'dh_user-settings', 'hidetb=1&libraryContent=browse'),
(19, 1, 'dh_user-settings-time', '1414489508'),
(20, 1, 'nav_menu_recently_edited', '13'),
(21, 1, 'active', '1'),
(22, 1, '_woocommerce_persistent_cart', 'a:1:{s:4:"cart";a:1:{s:32:"6f4922f45568161a8cdf4ad2299f6d23";a:9:{s:10:"product_id";i:18;s:12:"variation_id";s:0:"";s:9:"variation";s:0:"";s:8:"quantity";i:2;s:10:"line_total";d:29110;s:8:"line_tax";i:0;s:13:"line_subtotal";i:29110;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}}}') ;

#
# End of data contents of table `dh_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `dh_users`
#

DROP TABLE IF EXISTS `dh_users`;


#
# Table structure of table `dh_users`
#

CREATE TABLE `dh_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_users`
#
INSERT INTO `dh_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BRBKnRxF.ShX57wb0q.DQ0EY8mPhwl/', 'admin', 'admin@denimhouse.com', '', '2014-10-23 10:34:22', '', 0, 'admin') ;

#
# End of data contents of table `dh_users`
# --------------------------------------------------------



#
# Delete any existing table `dh_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `dh_woocommerce_attribute_taxonomies`;


#
# Table structure of table `dh_woocommerce_attribute_taxonomies`
#

CREATE TABLE `dh_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) NOT NULL,
  `attribute_label` longtext,
  `attribute_type` varchar(200) NOT NULL,
  `attribute_orderby` varchar(200) NOT NULL,
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_woocommerce_attribute_taxonomies`
#

#
# End of data contents of table `dh_woocommerce_attribute_taxonomies`
# --------------------------------------------------------



#
# Delete any existing table `dh_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `dh_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `dh_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `dh_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_id` varchar(32) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL DEFAULT '0',
  `order_key` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `downloads_remaining` varchar(9) DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`,`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_woocommerce_downloadable_product_permissions`
#

#
# End of data contents of table `dh_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------



#
# Delete any existing table `dh_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `dh_woocommerce_order_itemmeta`;


#
# Table structure of table `dh_woocommerce_order_itemmeta`
#

CREATE TABLE `dh_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_woocommerce_order_itemmeta`
#

#
# End of data contents of table `dh_woocommerce_order_itemmeta`
# --------------------------------------------------------



#
# Delete any existing table `dh_woocommerce_order_items`
#

DROP TABLE IF EXISTS `dh_woocommerce_order_items`;


#
# Table structure of table `dh_woocommerce_order_items`
#

CREATE TABLE `dh_woocommerce_order_items` (
  `order_item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_name` longtext NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT '',
  `order_id` bigint(20) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_woocommerce_order_items`
#

#
# End of data contents of table `dh_woocommerce_order_items`
# --------------------------------------------------------



#
# Delete any existing table `dh_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `dh_woocommerce_tax_rate_locations`;


#
# Table structure of table `dh_woocommerce_tax_rate_locations`
#

CREATE TABLE `dh_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `location_code` varchar(255) NOT NULL,
  `tax_rate_id` bigint(20) NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type` (`location_type`),
  KEY `location_type_code` (`location_type`,`location_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_woocommerce_tax_rate_locations`
#

#
# End of data contents of table `dh_woocommerce_tax_rate_locations`
# --------------------------------------------------------



#
# Delete any existing table `dh_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `dh_woocommerce_tax_rates`;


#
# Table structure of table `dh_woocommerce_tax_rates`
#

CREATE TABLE `dh_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) NOT NULL DEFAULT '',
  `tax_rate` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) NOT NULL,
  `tax_rate_class` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`),
  KEY `tax_rate_class` (`tax_rate_class`),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_woocommerce_tax_rates`
#

#
# End of data contents of table `dh_woocommerce_tax_rates`
# --------------------------------------------------------



#
# Delete any existing table `dh_woocommerce_termmeta`
#

DROP TABLE IF EXISTS `dh_woocommerce_termmeta`;


#
# Table structure of table `dh_woocommerce_termmeta`
#

CREATE TABLE `dh_woocommerce_termmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `woocommerce_term_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `woocommerce_term_id` (`woocommerce_term_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `dh_woocommerce_termmeta`
#

#
# End of data contents of table `dh_woocommerce_termmeta`
# --------------------------------------------------------

#
# Add constraints back in
#

